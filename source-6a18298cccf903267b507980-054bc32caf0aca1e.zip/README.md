# Mineralz Purple PvP

A premium gaming website for the **Mineralz Purple PvP** Minecraft texture pack — a free, competitive-grade PvP resource pack supporting both Bedrock and Java editions.

## What it is

This is a full-stack marketing + SaaS hybrid website built to showcase and distribute the Mineralz Purple PvP texture pack. It features a gaming-themed design with AAA-quality animations, user authentication, a downloads system, and a protected admin panel.

## Key Technologies

- **Framework**: [TanStack Start](https://tanstack.com/start) (React, SSR)
- **Styling**: [TailwindCSS v4](https://tailwindcss.com/) with custom CSS animations
- **Database**: [Netlify Database](https://docs.netlify.com/databases/) (Postgres via Drizzle ORM)
- **Auth**: [Netlify Identity](https://docs.netlify.com/security/secure-access-to-sites/identity/) via `@netlify/identity`
- **Animations**: Canvas API (falling blocks), CSS keyframes, custom hooks
- **Typography**: Press Start 2P (pixel), Inter (body)
- **Deployment**: [Netlify](https://netlify.com)

## Pages

| Route | Description |
|-------|-------------|
| `/` | Homepage — hero, stats, features, gallery, FAQ |
| `/downloads` | Pack downloads with chest animation |
| `/installation` | Interactive step-by-step install guide |
| `/changelog` | Version history timeline |
| `/faq` | Accordion FAQ page |
| `/login` | Login/signup with Google, GitHub, email |
| `/profile` | User profile, favorites, download history |
| `/admin` | Admin dashboard (restricted to `eepan7838@gmail.com`) |

## Running Locally

```bash
npm install
npm run dev
```

> **Note**: Authentication (Netlify Identity) only works on deployed Netlify environments — not on localhost. For auth testing, deploy a preview branch.

The dev server runs at `http://localhost:3000`.
