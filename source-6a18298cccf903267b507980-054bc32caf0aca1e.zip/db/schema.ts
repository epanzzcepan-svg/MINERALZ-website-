import { pgTable, serial, text, timestamp, integer, boolean, uuid } from "drizzle-orm/pg-core";

export const texturePacks = pgTable("texture_packs", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  version: text("version").notNull(),
  description: text("description").notNull().default(""),
  downloadUrl: text("download_url").notNull(),
  thumbnail: text("thumbnail").default(""),
  compatibility: text("compatibility").notNull().default("bedrock,java"),
  downloads: integer("downloads").notNull().default(0),
  visible: boolean("visible").notNull().default(true),
  changelog: text("changelog").default(""),
  createdAt: timestamp("created_at").defaultNow(),
});

export const userFavorites = pgTable("user_favorites", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  packId: integer("pack_id").notNull().references(() => texturePacks.id),
  createdAt: timestamp("created_at").defaultNow(),
});

export const downloadLogs = pgTable("download_logs", {
  id: serial("id").primaryKey(),
  userId: text("user_id"),
  packId: integer("pack_id").notNull().references(() => texturePacks.id),
  downloadedAt: timestamp("downloaded_at").defaultNow(),
});
