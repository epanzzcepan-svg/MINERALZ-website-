CREATE TABLE "download_logs" (
	"id" serial PRIMARY KEY,
	"user_id" text,
	"pack_id" integer NOT NULL,
	"downloaded_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "texture_packs" (
	"id" serial PRIMARY KEY,
	"name" text NOT NULL,
	"version" text NOT NULL,
	"description" text DEFAULT '' NOT NULL,
	"download_url" text NOT NULL,
	"thumbnail" text DEFAULT '',
	"compatibility" text DEFAULT 'bedrock,java' NOT NULL,
	"downloads" integer DEFAULT 0 NOT NULL,
	"visible" boolean DEFAULT true NOT NULL,
	"changelog" text DEFAULT '',
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "user_favorites" (
	"id" serial PRIMARY KEY,
	"user_id" text NOT NULL,
	"pack_id" integer NOT NULL,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
ALTER TABLE "download_logs" ADD CONSTRAINT "download_logs_pack_id_texture_packs_id_fkey" FOREIGN KEY ("pack_id") REFERENCES "texture_packs"("id");--> statement-breakpoint
ALTER TABLE "user_favorites" ADD CONSTRAINT "user_favorites_pack_id_texture_packs_id_fkey" FOREIGN KEY ("pack_id") REFERENCES "texture_packs"("id");