import { useState } from 'react'
import { ChevronDown } from 'lucide-react'

const FAQS = [
  { q: 'Is Mineralz Purple PvP free?', a: 'Yes, completely free. No subscriptions, no hidden costs, no locked content — ever. Download and enjoy forever.' },
  { q: 'Is the pack safe to download?', a: '100% safe. The pack is a standard .mcpack file with no executables. It only contains texture assets. You can inspect it yourself by renaming it to .zip.' },
  { q: 'Will this boost my FPS?', a: 'Yes! The textures are optimized to be lightweight. Most players report a 10–30 FPS improvement compared to default textures, especially on lower-end hardware.' },
  { q: 'Which Minecraft versions are supported?', a: 'The pack supports both Bedrock Edition (all platforms including mobile, console, Windows) and Java Edition (PC). One download works for both.' },
  { q: 'How do I install it?', a: 'For Bedrock: open the .mcpack file — Minecraft auto-imports it. Activate under Settings → Global Resources. For Java: place the .zip in your resourcepacks folder and enable in Options. Full guide on our Installation page.' },
  { q: 'Can I use it on servers?', a: 'Yes! Resource packs are client-side, so you can use Mineralz PvP on any server — Hypixel, Cubecraft, or your own private SMP.' },
]

export function FAQAccordion() {
  const [open, setOpen] = useState<number | null>(null)

  return (
    <section id="faq" className="section-padding">
      <div className="max-w-3xl mx-auto px-4">
        <div className="text-center mb-12">
          <p className="text-purple-400 text-sm font-semibold tracking-widest uppercase mb-3">Questions</p>
          <h2 className="pixel-font text-2xl sm:text-3xl gradient-text mb-4">FAQ</h2>
        </div>

        <div className="space-y-3">
          {FAQS.map((faq, i) => (
            <div
              key={i}
              className="glass-card rounded-2xl overflow-hidden transition-all duration-300"
              style={{ borderColor: open === i ? 'rgba(124,58,237,0.4)' : 'rgba(124,58,237,0.2)' }}
            >
              <button
                onClick={() => setOpen(open === i ? null : i)}
                className="w-full px-6 py-4 flex items-center justify-between text-left gap-4"
              >
                <span className="font-semibold text-white text-sm sm:text-base">{faq.q}</span>
                <ChevronDown
                  size={18}
                  className="text-purple-400 flex-shrink-0 transition-transform duration-300"
                  style={{ transform: open === i ? 'rotate(180deg)' : 'rotate(0deg)' }}
                />
              </button>
              <div
                className="overflow-hidden transition-all duration-300"
                style={{ maxHeight: open === i ? '200px' : '0px' }}
              >
                <p className="px-6 pb-5 text-gray-400 text-sm leading-relaxed">{faq.a}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
