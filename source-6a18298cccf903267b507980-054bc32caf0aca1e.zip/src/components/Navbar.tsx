import { useState, useEffect, useRef } from 'react'
import { Link, useLocation } from '@tanstack/react-router'
import { Menu, X, ChevronDown, LogOut, User, Heart, Download, Settings } from 'lucide-react'
import { useIdentity } from '../lib/identity-context'
import { ADMIN_EMAIL } from '../lib/auth'

const NAV_LINKS = [
  { label: 'Home', href: '/' },
  { label: 'Downloads', href: '/downloads' },
  { label: 'Installation', href: '/installation' },
  { label: 'Changelog', href: '/changelog' },
  { label: 'FAQ', href: '/faq' },
]

export function Navbar() {
  const [mobileOpen, setMobileOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)
  const [dropdownOpen, setDropdownOpen] = useState(false)
  const { user, ready, logout } = useIdentity()
  const location = useLocation()
  const dropdownRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20)
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setDropdownOpen(false)
      }
    }
    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])

  useEffect(() => {
    setMobileOpen(false)
  }, [location.pathname])

  const isAdmin = user?.email === ADMIN_EMAIL

  return (
    <>
      <nav
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          scrolled
            ? 'glass-card shadow-lg shadow-purple-900/20'
            : 'bg-transparent'
        }`}
        style={{ borderBottom: scrolled ? '1px solid rgba(124,58,237,0.2)' : 'none' }}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <Link to="/" className="flex items-center gap-2 group">
              <div className="w-8 h-8 rounded" style={{
                background: 'linear-gradient(135deg, #7c3aed, #a78bfa)',
                boxShadow: '0 0 12px rgba(124,58,237,0.6)',
                imageRendering: 'pixelated'
              }}>
                <div className="w-full h-full flex items-center justify-center text-white font-bold text-xs pixel-font">M</div>
              </div>
              <span className="pixel-font text-xs text-purple-300 group-hover:text-purple-200 transition-colors hidden sm:block">
                Mineralz<span className="text-purple-500"> PvP</span>
              </span>
            </Link>

            {/* Desktop nav */}
            <div className="hidden md:flex items-center gap-1">
              {NAV_LINKS.map((link) => (
                <Link
                  key={link.href}
                  to={link.href}
                  className={`px-3 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
                    location.pathname === link.href
                      ? 'text-purple-300 bg-purple-900/30'
                      : 'text-gray-400 hover:text-purple-300 hover:bg-purple-900/20'
                  }`}
                >
                  {link.label}
                </Link>
              ))}
              {isAdmin && (
                <Link
                  to="/admin"
                  className="px-3 py-2 rounded-lg text-sm font-medium text-yellow-400 hover:text-yellow-300 hover:bg-yellow-900/20 transition-all"
                >
                  Admin
                </Link>
              )}
            </div>

            {/* Auth section */}
            <div className="flex items-center gap-3">
              {!ready ? (
                <div className="w-8 h-8 rounded-full bg-purple-900/40 animate-pulse" />
              ) : user ? (
                <div className="relative" ref={dropdownRef}>
                  <button
                    onClick={() => setDropdownOpen(!dropdownOpen)}
                    className="flex items-center gap-2 px-3 py-1.5 rounded-lg glass-card hover:border-purple-500/50 transition-all"
                  >
                    {user.pictureUrl ? (
                      <img src={user.pictureUrl} alt={user.name} className="w-6 h-6 rounded-full" />
                    ) : (
                      <div className="w-6 h-6 rounded-full bg-purple-600 flex items-center justify-center text-white text-xs font-bold">
                        {(user.name || user.email || 'U')[0].toUpperCase()}
                      </div>
                    )}
                    <span className="text-sm text-gray-300 hidden sm:block max-w-[100px] truncate">
                      {user.name || user.email}
                    </span>
                    <ChevronDown size={14} className={`text-gray-400 transition-transform ${dropdownOpen ? 'rotate-180' : ''}`} />
                  </button>
                  {dropdownOpen && (
                    <div className="absolute right-0 top-full mt-2 w-48 glass-card rounded-xl shadow-xl shadow-purple-900/30 overflow-hidden">
                      <Link to="/profile" className="flex items-center gap-2 px-4 py-3 text-sm text-gray-300 hover:text-purple-300 hover:bg-purple-900/30 transition-all">
                        <User size={14} /> Profile
                      </Link>
                      <Link to="/profile?tab=favorites" className="flex items-center gap-2 px-4 py-3 text-sm text-gray-300 hover:text-purple-300 hover:bg-purple-900/30 transition-all">
                        <Heart size={14} /> Favorites
                      </Link>
                      <Link to="/profile?tab=history" className="flex items-center gap-2 px-4 py-3 text-sm text-gray-300 hover:text-purple-300 hover:bg-purple-900/30 transition-all">
                        <Download size={14} /> Download History
                      </Link>
                      {isAdmin && (
                        <Link to="/admin" className="flex items-center gap-2 px-4 py-3 text-sm text-yellow-400 hover:text-yellow-300 hover:bg-yellow-900/20 transition-all">
                          <Settings size={14} /> Admin Panel
                        </Link>
                      )}
                      <div className="border-t border-purple-900/40 my-1" />
                      <button
                        onClick={() => { logout(); setDropdownOpen(false) }}
                        className="flex items-center gap-2 px-4 py-3 text-sm text-red-400 hover:text-red-300 hover:bg-red-900/20 transition-all w-full text-left"
                      >
                        <LogOut size={14} /> Logout
                      </button>
                    </div>
                  )}
                </div>
              ) : (
                <Link
                  to="/login"
                  className="glow-btn px-4 py-2 rounded-lg text-sm font-semibold text-white"
                >
                  Login
                </Link>
              )}

              {/* Mobile hamburger */}
              <button
                onClick={() => setMobileOpen(!mobileOpen)}
                className="md:hidden p-2 rounded-lg glass-card hover:border-purple-500/50 transition-all"
              >
                {mobileOpen ? <X size={18} className="text-gray-300" /> : <Menu size={18} className="text-gray-300" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile menu */}
        <div
          className={`md:hidden overflow-hidden transition-all duration-300 ${mobileOpen ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0'}`}
          style={{ background: 'rgba(10,5,20,0.95)', backdropFilter: 'blur(20px)' }}
        >
          <div className="px-4 pb-4 space-y-1">
            {NAV_LINKS.map((link) => (
              <Link
                key={link.href}
                to={link.href}
                className={`block px-4 py-3 rounded-lg text-sm font-medium transition-all ${
                  location.pathname === link.href
                    ? 'text-purple-300 bg-purple-900/30'
                    : 'text-gray-400 hover:text-purple-300 hover:bg-purple-900/20'
                }`}
              >
                {link.label}
              </Link>
            ))}
            {isAdmin && (
              <Link to="/admin" className="block px-4 py-3 rounded-lg text-sm font-medium text-yellow-400 hover:bg-yellow-900/20">
                Admin Panel
              </Link>
            )}
          </div>
        </div>
      </nav>
      {/* Spacer */}
      <div className="h-16" />
    </>
  )
}
