import { useEffect, useRef, useState } from 'react'
import { Link } from '@tanstack/react-router'
import { Download, ChevronDown } from 'lucide-react'

// Block types with pixel colors
const BLOCK_TYPES = [
  { name: 'grass', top: '#5a8a3c', side: '#8b6347', bottom: '#7a5a32' },
  { name: 'stone', top: '#888', side: '#777', bottom: '#666' },
  { name: 'diamond', top: '#4de8e8', side: '#3dd0d0', bottom: '#2eb8b8' },
  { name: 'gold', top: '#f5c542', side: '#e0a820', bottom: '#c89010' },
  { name: 'obsidian', top: '#2a1a3e', side: '#1e1228', bottom: '#160e1e' },
]

interface Block {
  x: number
  y: number
  vx: number
  vy: number
  rot: number
  rotV: number
  size: number
  type: (typeof BLOCK_TYPES)[number]
  opacity: number
}

function drawIsometricBlock(ctx: CanvasRenderingContext2D, x: number, y: number, size: number, block: (typeof BLOCK_TYPES)[number], opacity: number) {
  ctx.save()
  ctx.globalAlpha = opacity
  const s = size
  const h = s * 0.5

  // Top face
  ctx.fillStyle = block.top
  ctx.beginPath()
  ctx.moveTo(x, y - h)
  ctx.lineTo(x + s, y)
  ctx.lineTo(x, y + h)
  ctx.lineTo(x - s, y)
  ctx.closePath()
  ctx.fill()

  // Right face
  ctx.fillStyle = block.side
  ctx.beginPath()
  ctx.moveTo(x + s, y)
  ctx.lineTo(x + s, y + s)
  ctx.lineTo(x, y + s + h)
  ctx.lineTo(x, y + h)
  ctx.closePath()
  ctx.fill()

  // Left face
  ctx.fillStyle = block.bottom
  ctx.beginPath()
  ctx.moveTo(x - s, y)
  ctx.lineTo(x - s, y + s)
  ctx.lineTo(x, y + s + h)
  ctx.lineTo(x, y + h)
  ctx.closePath()
  ctx.fill()

  // Stroke edges
  ctx.strokeStyle = 'rgba(0,0,0,0.4)'
  ctx.lineWidth = 1

  ctx.beginPath()
  ctx.moveTo(x, y - h)
  ctx.lineTo(x + s, y)
  ctx.lineTo(x + s, y + s)
  ctx.lineTo(x, y + s + h)
  ctx.lineTo(x - s, y + s)
  ctx.lineTo(x - s, y)
  ctx.closePath()
  ctx.stroke()

  ctx.beginPath()
  ctx.moveTo(x, y - h)
  ctx.lineTo(x, y + h)
  ctx.moveTo(x, y + h)
  ctx.lineTo(x, y + s + h)
  ctx.stroke()

  ctx.restore()
}

function useTypewriter(phrases: string[], speed = 80) {
  const [display, setDisplay] = useState('')
  const [phraseIdx, setPhraseIdx] = useState(0)
  const [charIdx, setCharIdx] = useState(0)
  const [deleting, setDeleting] = useState(false)

  useEffect(() => {
    const current = phrases[phraseIdx]
    let timeout: ReturnType<typeof setTimeout>

    if (!deleting && charIdx < current.length) {
      timeout = setTimeout(() => setCharIdx((c) => c + 1), speed)
    } else if (!deleting && charIdx === current.length) {
      timeout = setTimeout(() => setDeleting(true), 2000)
    } else if (deleting && charIdx > 0) {
      timeout = setTimeout(() => setCharIdx((c) => c - 1), speed / 2)
    } else if (deleting && charIdx === 0) {
      setDeleting(false)
      setPhraseIdx((i) => (i + 1) % phrases.length)
    }

    setDisplay(current.slice(0, charIdx))
    return () => clearTimeout(timeout)
  }, [charIdx, deleting, phraseIdx, phrases, speed])

  return display
}

export function Hero() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const blocksRef = useRef<Block[]>([])
  const animRef = useRef<number>(0)
  const typeText = useTypewriter([
    'The Ultimate PvP Texture Pack',
    'Dominate Every Battle',
    'Premium Quality. Forever Free.',
  ])

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return

    function resize() {
      if (!canvas) return
      canvas.width = canvas.offsetWidth
      canvas.height = canvas.offsetHeight
    }
    resize()
    window.addEventListener('resize', resize)

    function spawnBlock() {
      if (!canvas) return
      const type = BLOCK_TYPES[Math.floor(Math.random() * BLOCK_TYPES.length)]
      blocksRef.current.push({
        x: Math.random() * canvas.width,
        y: -80,
        vx: (Math.random() - 0.5) * 0.8,
        vy: 0.4 + Math.random() * 0.8,
        rot: Math.random() * Math.PI * 2,
        rotV: (Math.random() - 0.5) * 0.02,
        size: 18 + Math.random() * 24,
        type,
        opacity: 0.12 + Math.random() * 0.18,
      })
    }

    let frameCount = 0
    function animate() {
      if (!canvas || !ctx) return
      ctx.clearRect(0, 0, canvas.width, canvas.height)

      frameCount++
      if (frameCount % 40 === 0 && blocksRef.current.length < 20) {
        spawnBlock()
      }

      blocksRef.current = blocksRef.current.filter((b) => b.y < canvas.height + 100)

      for (const block of blocksRef.current) {
        block.x += block.vx
        block.y += block.vy
        block.rot += block.rotV

        ctx.save()
        ctx.translate(block.x, block.y)
        ctx.rotate(block.rot)
        drawIsometricBlock(ctx, 0, 0, block.size, block.type, block.opacity)
        ctx.restore()
      }

      animRef.current = requestAnimationFrame(animate)
    }

    // Spawn initial blocks
    for (let i = 0; i < 8; i++) {
      setTimeout(spawnBlock, i * 500)
    }

    animate()

    return () => {
      cancelAnimationFrame(animRef.current)
      window.removeEventListener('resize', resize)
    }
  }, [])

  return (
    <section className="relative min-h-screen flex flex-col items-center justify-center overflow-hidden" style={{
      background: 'linear-gradient(160deg, #0a0a0a 0%, #0f0520 40%, #1a0a2e 80%, #0a0a1e 100%)'
    }}>
      {/* Canvas falling blocks */}
      <canvas
        ref={canvasRef}
        className="absolute inset-0 w-full h-full pointer-events-none"
        aria-hidden="true"
      />

      {/* Background grid */}
      <div className="absolute inset-0 bg-grid opacity-40 pointer-events-none" />

      {/* Radial glow */}
      <div className="absolute inset-0 pointer-events-none" style={{
        background: 'radial-gradient(ellipse 60% 50% at 50% 50%, rgba(124,58,237,0.15) 0%, transparent 70%)',
        animation: 'pulseGlow 4s ease-in-out infinite'
      }} />

      {/* XP Bar */}
      <div className="absolute top-20 left-0 right-0 flex justify-center px-4 z-10">
        <div className="w-full max-w-xs">
          <div className="flex justify-between text-xs text-purple-400 mb-1 pixel-font" style={{ fontSize: '8px' }}>
            <span>XP</span>
            <span>Level 73</span>
          </div>
          <div className="h-3 rounded-full overflow-hidden" style={{ background: 'rgba(124,58,237,0.15)', border: '1px solid rgba(124,58,237,0.3)' }}>
            <div
              className="h-full rounded-full xp-bar-fill"
              style={{ background: 'linear-gradient(90deg, #5b21b6, #7c3aed, #a78bfa)', boxShadow: '0 0 8px rgba(124,58,237,0.8)' }}
            />
          </div>
        </div>
      </div>

      {/* Floating pixel sword */}
      <div className="absolute right-[15%] top-[30%] float-anim pointer-events-none opacity-20 hidden lg:block">
        <div className="relative" style={{ width: 16, height: 64 }}>
          {/* Sword pixel art */}
          {[
            [0,0,'#a78bfa'],[0,1,'#a78bfa'],[0,2,'#8b5cf6'],[0,3,'#8b5cf6'],[0,4,'#7c3aed'],[0,5,'#7c3aed'],
            [0,6,'#6d28d9'],[0,7,'#5b21b6'],[0,8,'#4c1d95'],[0,9,'#f5c542'],[1,9,'#f5c542'],
          ].map(([col, row, color], i) => (
            <div key={i} style={{
              position: 'absolute', width: 8, height: 8,
              left: (col as number) * 8, top: (row as number) * 8,
              background: color as string, imageRendering: 'pixelated'
            }} />
          ))}
        </div>
      </div>

      {/* Purple enchantment particles */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {Array.from({ length: 20 }).map((_, i) => (
          <div
            key={i}
            className="absolute w-1 h-1 rounded-full"
            style={{
              background: `rgba(167,139,250,${0.4 + Math.random() * 0.6})`,
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              boxShadow: '0 0 4px rgba(167,139,250,0.8)',
              animation: `enchantDrift ${2 + Math.random() * 4}s ease-out ${Math.random() * 5}s infinite`,
            }}
          />
        ))}
      </div>

      {/* Main content */}
      <div className="relative z-10 text-center px-4 max-w-4xl mx-auto">
        {/* Badge */}
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full mb-8 text-xs font-semibold text-purple-300"
          style={{ background: 'rgba(124,58,237,0.15)', border: '1px solid rgba(124,58,237,0.3)' }}>
          <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
          v1.0 — Bedrock + Java
        </div>

        {/* Title */}
        <h1 className="pixel-font mb-4 leading-tight" style={{ fontSize: 'clamp(1.2rem, 4vw, 2.2rem)' }}>
          <span className="gradient-text">Mineralz</span>
          <br />
          <span className="text-white">Purple PvP</span>
        </h1>

        {/* Typewriter */}
        <div className="h-12 flex items-center justify-center mb-6">
          <p className="text-lg sm:text-xl text-purple-200 font-medium min-h-[1.5rem]">
            {typeText}
            <span className="inline-block w-0.5 h-5 bg-purple-400 ml-1 animate-pulse align-middle" />
          </p>
        </div>

        <p className="text-gray-400 text-base sm:text-lg max-w-xl mx-auto mb-10">
          A premium Minecraft texture pack crafted for competitive PvP — sharper visuals, smoother animations, and zero compromise on performance.
        </p>

        {/* CTAs */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
          <a
            href="https://drive.google.com/uc?export=download&id=11B4i7_0KNS0N6MMu6QipXvmDA32EDjJz"
            className="glow-btn px-8 py-4 rounded-xl text-white font-bold text-lg flex items-center gap-2"
          >
            <Download size={20} />
            Download Free
          </a>
          <Link
            to="/installation"
            className="px-8 py-4 rounded-xl font-semibold text-purple-300 text-lg transition-all hover:text-white"
            style={{ background: 'rgba(124,58,237,0.1)', border: '1px solid rgba(124,58,237,0.3)' }}
          >
            View Guide
          </Link>
        </div>

        {/* Stats row */}
        <div className="flex items-center justify-center gap-6 mt-12 text-sm text-gray-500">
          <span className="flex items-center gap-1.5"><span className="text-purple-400 font-bold">10K+</span> Downloads</span>
          <span className="w-px h-4 bg-purple-900" />
          <span className="flex items-center gap-1.5"><span className="text-purple-400 font-bold">160+</span> Textures</span>
          <span className="w-px h-4 bg-purple-900" />
          <span className="flex items-center gap-1.5"><span className="text-green-400 font-bold">100%</span> Free</span>
        </div>
      </div>

      {/* Dirt/grass border bottom */}
      <div className="absolute bottom-0 left-0 right-0 h-16 pointer-events-none" style={{
        backgroundImage: 'repeating-linear-gradient(90deg, #5a8a3c 0px, #5a8a3c 16px, #4a7a2c 16px, #4a7a2c 32px)',
        backgroundSize: '32px 8px',
        backgroundRepeat: 'repeat-x',
        backgroundPosition: 'bottom',
        maskImage: 'linear-gradient(to top, black 0%, transparent 100%)',
      }}>
        <div style={{
          position: 'absolute', bottom: 8, left: 0, right: 0, height: 8,
          backgroundImage: 'repeating-linear-gradient(90deg, #8b6347 0px, #8b6347 16px, #7a5432 16px, #7a5432 32px)',
          backgroundSize: '32px 8px',
          backgroundRepeat: 'repeat-x',
        }} />
      </div>

      {/* Scroll indicator */}
      <a href="#stats" className="absolute bottom-20 left-1/2 -translate-x-1/2 z-10 flex flex-col items-center gap-1 text-purple-400 opacity-60 hover:opacity-100 transition-opacity">
        <span className="text-xs">Scroll</span>
        <ChevronDown size={16} className="animate-bounce" />
      </a>
    </section>
  )
}
