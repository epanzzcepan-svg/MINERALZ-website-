import { useEffect, useRef, useState } from 'react'

interface StatItem {
  value: number
  suffix: string
  label: string
  icon: string
}

const STATS: StatItem[] = [
  { value: 10000, suffix: '+', label: 'Downloads', icon: '⬇' },
  { value: 2, suffix: '', label: 'Platforms', icon: '🎮' },
  { value: 160, suffix: '+', label: 'Texture Changes', icon: '🎨' },
  { value: 100, suffix: '%', label: 'Free Forever', icon: '💜' },
]

function useCountUp(target: number, duration = 2000, started: boolean) {
  const [count, setCount] = useState(0)

  useEffect(() => {
    if (!started) return
    const start = performance.now()
    function update(now: number) {
      const elapsed = now - start
      const progress = Math.min(elapsed / duration, 1)
      const eased = 1 - Math.pow(1 - progress, 3)
      setCount(Math.floor(eased * target))
      if (progress < 1) requestAnimationFrame(update)
    }
    requestAnimationFrame(update)
  }, [started, target, duration])

  return count
}

function StatCard({ stat, started }: { stat: StatItem; started: boolean }) {
  const count = useCountUp(stat.value, 2000, started)

  return (
    <div className="glass-card rounded-2xl p-6 text-center hover:border-purple-500/50 transition-all duration-300 group">
      <div className="text-3xl mb-2">{stat.icon}</div>
      <div className="pixel-font text-2xl sm:text-3xl mb-2" style={{
        background: 'linear-gradient(135deg, #a78bfa, #7c3aed)',
        WebkitBackgroundClip: 'text',
        WebkitTextFillColor: 'transparent',
      }}>
        {count.toLocaleString()}{stat.suffix}
      </div>
      <div className="text-gray-400 text-sm font-medium">{stat.label}</div>
    </div>
  )
}

export function StatsCounter() {
  const [started, setStarted] = useState(false)
  const ref = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setStarted(true) },
      { threshold: 0.3 }
    )
    if (ref.current) observer.observe(ref.current)
    return () => observer.disconnect()
  }, [])

  return (
    <section id="stats" ref={ref} className="section-padding" style={{ background: 'rgba(124,58,237,0.03)' }}>
      <div className="max-w-5xl mx-auto">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {STATS.map((stat) => (
            <StatCard key={stat.label} stat={stat} started={started} />
          ))}
        </div>
      </div>
    </section>
  )
}
