import { useState } from 'react'
import { X, ChevronLeft, ChevronRight } from 'lucide-react'

type FilterTab = 'all' | 'pvp' | 'items' | 'ui' | 'blocks'

const SCREENSHOTS = [
  { id: 1, src: '/placeholder.png', alt: 'PvP Combat', tab: 'pvp' as const, label: 'Sharp PvP Combat' },
  { id: 2, src: '/placeholder.png', alt: 'Items Inventory', tab: 'items' as const, label: 'Clean Item Textures' },
  { id: 3, src: '/placeholder.png', alt: 'HUD Interface', tab: 'ui' as const, label: 'Redesigned HUD' },
  { id: 4, src: '/placeholder.png', alt: 'Block Textures', tab: 'blocks' as const, label: 'Crisp Block Textures' },
  { id: 5, src: '/placeholder.png', alt: 'Sword Fight', tab: 'pvp' as const, label: 'Sword Animations' },
  { id: 6, src: '/placeholder.png', alt: 'Inventory UI', tab: 'ui' as const, label: 'Inventory Overhaul' },
  { id: 7, src: '/placeholder.png', alt: 'Diamond Gear', tab: 'items' as const, label: 'Diamond Armor' },
  { id: 8, src: '/placeholder.png', alt: 'Cave Blocks', tab: 'blocks' as const, label: 'Cave Generation' },
]

const TABS: { id: FilterTab; label: string }[] = [
  { id: 'all', label: 'All' },
  { id: 'pvp', label: 'PvP' },
  { id: 'items', label: 'Items' },
  { id: 'ui', label: 'UI' },
  { id: 'blocks', label: 'Blocks' },
]

export function ScreenshotGallery() {
  const [activeTab, setActiveTab] = useState<FilterTab>('all')
  const [lightbox, setLightbox] = useState<number | null>(null)

  const filtered = activeTab === 'all' ? SCREENSHOTS : SCREENSHOTS.filter((s) => s.tab === activeTab)

  function navigate(dir: 1 | -1) {
    if (lightbox === null) return
    const newIdx = (lightbox + dir + filtered.length) % filtered.length
    setLightbox(newIdx)
  }

  return (
    <section id="screenshots" className="section-padding" style={{ background: 'rgba(124,58,237,0.03)' }}>
      <div className="max-w-6xl mx-auto px-4">
        <div className="text-center mb-12">
          <p className="text-purple-400 text-sm font-semibold tracking-widest uppercase mb-3">Gallery</p>
          <h2 className="pixel-font text-2xl sm:text-3xl gradient-text mb-4">See It In Action</h2>
          <p className="text-gray-400 max-w-xl mx-auto">
            Real screenshots from the pack — no filters, no post-processing.
          </p>
        </div>

        {/* Filter tabs */}
        <div className="flex items-center justify-center gap-2 mb-8 flex-wrap">
          {TABS.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-5 py-2 rounded-full text-sm font-semibold transition-all duration-200 ${
                activeTab === tab.id
                  ? 'text-white'
                  : 'text-gray-400 hover:text-purple-300'
              }`}
              style={{
                background: activeTab === tab.id ? 'linear-gradient(135deg, #7c3aed, #6d28d9)' : 'rgba(124,58,237,0.1)',
                border: '1px solid',
                borderColor: activeTab === tab.id ? 'transparent' : 'rgba(124,58,237,0.2)',
                boxShadow: activeTab === tab.id ? '0 0 16px rgba(124,58,237,0.4)' : 'none',
              }}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Masonry grid */}
        <div className="columns-2 md:columns-3 lg:columns-4 gap-4 space-y-4">
          {filtered.map((screenshot, i) => (
            <div
              key={screenshot.id}
              className="break-inside-avoid rounded-xl overflow-hidden cursor-pointer group relative"
              onClick={() => setLightbox(i)}
              style={{ border: '1px solid rgba(124,58,237,0.2)' }}
            >
              <img
                src={screenshot.src}
                alt={screenshot.alt}
                className="w-full object-cover transition-transform duration-500 group-hover:scale-105"
                style={{ minHeight: i % 3 === 0 ? 200 : 140 }}
                loading="lazy"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-purple-950/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-3">
                <span className="text-white text-xs font-semibold">{screenshot.label}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Lightbox */}
      {lightbox !== null && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center lightbox-overlay"
          style={{ background: 'rgba(0,0,0,0.85)' }}
          onClick={() => setLightbox(null)}
        >
          <div
            className="relative max-w-4xl w-full mx-4"
            onClick={(e) => e.stopPropagation()}
          >
            <img
              src={filtered[lightbox].src}
              alt={filtered[lightbox].alt}
              className="w-full rounded-2xl"
              style={{ border: '1px solid rgba(124,58,237,0.3)' }}
            />
            <p className="text-center text-purple-300 mt-3 font-medium">{filtered[lightbox].label}</p>

            <button
              onClick={() => setLightbox(null)}
              className="absolute top-3 right-3 p-2 rounded-full bg-black/60 text-white hover:bg-purple-900/60 transition-all"
            >
              <X size={18} />
            </button>
            <button
              onClick={() => navigate(-1)}
              className="absolute left-3 top-1/2 -translate-y-1/2 p-2 rounded-full bg-black/60 text-white hover:bg-purple-900/60 transition-all"
            >
              <ChevronLeft size={20} />
            </button>
            <button
              onClick={() => navigate(1)}
              className="absolute right-3 top-1/2 -translate-y-1/2 p-2 rounded-full bg-black/60 text-white hover:bg-purple-900/60 transition-all"
            >
              <ChevronRight size={20} />
            </button>
          </div>
        </div>
      )}
    </section>
  )
}
