import { useState } from 'react'
import { Zap, Shield, Eye, Cpu, Sword, Layers } from 'lucide-react'

const FEATURES = [
  {
    icon: Sword,
    title: 'PvP Optimized',
    description: 'Sharper hit boxes, cleaner animations, and high-contrast textures built specifically for competitive play.',
    color: '#ef4444',
  },
  {
    icon: Eye,
    title: 'Crystal Clear UI',
    description: 'Redesigned HUD and inventory with better readability under stress. Know your status at a glance.',
    color: '#3b82f6',
  },
  {
    icon: Zap,
    title: 'FPS Boost',
    description: 'Lightweight, optimized textures that reduce GPU load — gain frames without sacrificing looks.',
    color: '#f59e0b',
  },
  {
    icon: Shield,
    title: 'Dual Platform',
    description: 'Fully compatible with both Bedrock and Java editions. One pack, every platform.',
    color: '#10b981',
  },
  {
    icon: Cpu,
    title: '160+ Changes',
    description: 'Over 160 hand-crafted texture changes — from mobs to blocks to particles and beyond.',
    color: '#8b5cf6',
  },
  {
    icon: Layers,
    title: '100% Free',
    description: 'No subscriptions, no paywalls, no locked content. Premium quality forever free.',
    color: '#ec4899',
  },
]

export function FeaturesGrid() {
  const [hovered, setHovered] = useState<number | null>(null)

  return (
    <section id="features" className="section-padding">
      <div className="max-w-6xl mx-auto px-4">
        <div className="text-center mb-16">
          <p className="text-purple-400 text-sm font-semibold tracking-widest uppercase mb-3">Why Mineralz?</p>
          <h2 className="pixel-font text-2xl sm:text-3xl gradient-text mb-4">Built for Winners</h2>
          <p className="text-gray-400 max-w-xl mx-auto">
            Every texture, every animation, every pixel — meticulously tuned for the competitive Minecraft player.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {FEATURES.map((feature, i) => {
            const Icon = feature.icon
            const isHovered = hovered === i
            return (
              <div
                key={i}
                onMouseEnter={() => setHovered(i)}
                onMouseLeave={() => setHovered(null)}
                className="glass-card rounded-2xl p-6 cursor-default transition-all duration-300"
                style={{
                  transform: isHovered ? 'translateY(-4px) rotate(0.5deg)' : 'translateY(0) rotate(0)',
                  borderColor: isHovered ? `${feature.color}40` : 'rgba(124,58,237,0.2)',
                  boxShadow: isHovered ? `0 12px 40px ${feature.color}20, 0 0 0 1px ${feature.color}30` : 'none',
                }}
              >
                <div
                  className="w-12 h-12 rounded-xl flex items-center justify-center mb-4 transition-all duration-300"
                  style={{
                    background: isHovered ? `${feature.color}20` : 'rgba(124,58,237,0.1)',
                    boxShadow: isHovered ? `0 0 20px ${feature.color}30` : 'none',
                  }}
                >
                  <Icon size={22} style={{ color: isHovered ? feature.color : '#a78bfa' }} />
                </div>
                <h3 className="font-bold text-white mb-2 text-lg">{feature.title}</h3>
                <p className="text-gray-400 text-sm leading-relaxed">{feature.description}</p>
              </div>
            )
          })}
        </div>
      </div>
    </section>
  )
}
