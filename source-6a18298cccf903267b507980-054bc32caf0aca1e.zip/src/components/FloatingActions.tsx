import { useState, useEffect } from 'react'
import { Download, ArrowUp, Volume2, VolumeX } from 'lucide-react'

const KONAMI = ['ArrowUp','ArrowUp','ArrowDown','ArrowDown','ArrowLeft','ArrowRight','ArrowLeft','ArrowRight','b','a']

export function FloatingActions() {
  const [showTop, setShowTop] = useState(false)
  const [soundOn, setSoundOn] = useState(false)
  const [konamiIdx, setKonamiIdx] = useState(0)
  const [konamiActive, setKonamiActive] = useState(false)

  useEffect(() => {
    const onScroll = () => setShowTop(window.scrollY > 300)
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      const expected = KONAMI[konamiIdx]
      if (e.key === expected) {
        const next = konamiIdx + 1
        if (next === KONAMI.length) {
          setKonamiActive(true)
          setKonamiIdx(0)
        } else {
          setKonamiIdx(next)
        }
      } else {
        setKonamiIdx(0)
      }
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [konamiIdx])

  function playClick() {
    if (!soundOn) return
    try {
      const ctx = new AudioContext()
      const osc = ctx.createOscillator()
      const gain = ctx.createGain()
      osc.connect(gain)
      gain.connect(ctx.destination)
      osc.frequency.value = 800
      gain.gain.setValueAtTime(0.1, ctx.currentTime)
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.1)
      osc.start()
      osc.stop(ctx.currentTime + 0.1)
    } catch {}
  }

  return (
    <>
      {/* Floating download CTA */}
      <div className="fixed bottom-6 right-6 z-40 flex flex-col gap-3">
        {showTop && (
          <button
            onClick={() => { window.scrollTo({ top: 0, behavior: 'smooth' }); playClick() }}
            className="w-11 h-11 rounded-xl glass-card flex items-center justify-center text-purple-300 hover:text-white hover:border-purple-500/60 transition-all"
            aria-label="Back to top"
          >
            <ArrowUp size={18} />
          </button>
        )}
        <button
          onClick={() => setSoundOn(!soundOn)}
          className="w-11 h-11 rounded-xl glass-card flex items-center justify-center text-purple-300 hover:text-white hover:border-purple-500/60 transition-all"
          aria-label="Toggle sound"
          title={soundOn ? 'Mute click sounds' : 'Enable click sounds'}
        >
          {soundOn ? <Volume2 size={18} /> : <VolumeX size={18} />}
        </button>
        <a
          href="https://drive.google.com/uc?export=download&id=11B4i7_0KNS0N6MMu6QipXvmDA32EDjJz"
          className="glow-btn w-14 h-14 rounded-2xl flex items-center justify-center text-white pulse-glow"
          aria-label="Download pack"
          onClick={playClick}
        >
          <Download size={22} />
        </a>
      </div>

      {/* Konami Easter Egg modal */}
      {konamiActive && (
        <div
          className="fixed inset-0 z-[100] flex items-center justify-center"
          style={{ background: 'rgba(0,0,0,0.9)', backdropFilter: 'blur(20px)' }}
          onClick={() => setKonamiActive(false)}
        >
          <div
            className="glass-card rounded-3xl p-10 max-w-sm mx-4 text-center"
            style={{ border: '2px solid rgba(124,58,237,0.6)', boxShadow: '0 0 60px rgba(124,58,237,0.4)' }}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="text-6xl mb-4">🎮</div>
            <h3 className="pixel-font text-lg text-purple-300 mb-3">Cheat Code!</h3>
            <p className="text-gray-300 text-sm leading-relaxed mb-2">
              You found the secret! You're clearly a true gamer.
            </p>
            <p className="text-purple-400 text-xs mb-6 pixel-font">+30 Lives</p>
            <div className="text-4xl mb-6 animate-bounce">💜</div>
            <button
              onClick={() => setKonamiActive(false)}
              className="glow-btn px-6 py-3 rounded-xl text-white font-semibold text-sm"
            >
              Continue Playing
            </button>
          </div>
        </div>
      )}
    </>
  )
}
