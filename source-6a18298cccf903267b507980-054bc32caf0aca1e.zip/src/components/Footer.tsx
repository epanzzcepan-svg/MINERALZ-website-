import { Link } from '@tanstack/react-router'
import { Github, Twitter, Youtube, MessageCircle } from 'lucide-react'

export function Footer() {
  return (
    <footer className="relative border-t" style={{ borderColor: 'rgba(124,58,237,0.15)' }}>
      {/* Animated bg grid */}
      <div className="absolute inset-0 bg-grid opacity-20 pointer-events-none" />

      <div className="relative max-w-6xl mx-auto px-4 py-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-10">
          {/* Brand */}
          <div className="md:col-span-2">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 rounded pixel-font flex items-center justify-center text-white font-bold text-xs"
                style={{ background: 'linear-gradient(135deg, #7c3aed, #a78bfa)', boxShadow: '0 0 12px rgba(124,58,237,0.6)' }}>
                M
              </div>
              <span className="pixel-font text-xs text-purple-300">Mineralz Purple PvP</span>
            </div>
            <p className="text-gray-500 text-sm leading-relaxed max-w-xs">
              The ultimate Minecraft PvP texture pack. Free forever, optimized for every platform.
            </p>
            <div className="flex items-center gap-3 mt-5">
              {[
                { icon: Github, label: 'GitHub', href: '#' },
                { icon: Twitter, label: 'Twitter', href: '#' },
                { icon: Youtube, label: 'YouTube', href: '#' },
                { icon: MessageCircle, label: 'Discord', href: '#' },
              ].map(({ icon: Icon, label, href }) => (
                <a key={label} href={href} aria-label={label}
                  className="w-9 h-9 rounded-lg glass-card flex items-center justify-center text-gray-400 hover:text-purple-300 hover:border-purple-500/50 transition-all">
                  <Icon size={16} />
                </a>
              ))}
            </div>
          </div>

          {/* Links */}
          <div>
            <h4 className="text-white font-semibold text-sm mb-4">Pack</h4>
            <ul className="space-y-2">
              {[
                { label: 'Downloads', href: '/downloads' },
                { label: 'Changelog', href: '/changelog' },
                { label: 'Screenshots', href: '/#screenshots' },
                { label: 'Features', href: '/#features' },
              ].map((l) => (
                <li key={l.label}>
                  <Link to={l.href} className="text-gray-500 text-sm hover:text-purple-300 transition-colors">{l.label}</Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-white font-semibold text-sm mb-4">Support</h4>
            <ul className="space-y-2">
              {[
                { label: 'Installation Guide', href: '/installation' },
                { label: 'FAQ', href: '/faq' },
              ].map((l) => (
                <li key={l.label}>
                  <Link to={l.href} className="text-gray-500 text-sm hover:text-purple-300 transition-colors">{l.label}</Link>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="border-t mt-12 pt-8 flex flex-col sm:flex-row items-center justify-between gap-4"
          style={{ borderColor: 'rgba(124,58,237,0.1)' }}>
          <p className="text-gray-600 text-xs">
            © {new Date().getFullYear()} Mineralz Purple PvP. Not affiliated with Mojang or Microsoft.
          </p>
          <p className="text-gray-600 text-xs">
            Made with 💜 for the Minecraft community
          </p>
        </div>
      </div>
    </footer>
  )
}
