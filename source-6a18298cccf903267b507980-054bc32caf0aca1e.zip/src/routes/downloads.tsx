import { createFileRoute } from '@tanstack/react-router'
import { useState, useEffect } from 'react'
import { Download, Heart, Star, ExternalLink } from 'lucide-react'
import { getPacks, incrementDownload, getUserFavorites, toggleFavorite } from '../lib/packs'
import { useIdentity } from '../lib/identity-context'

type Pack = {
  id: number
  name: string
  version: string
  description: string
  downloadUrl: string
  thumbnail: string | null
  compatibility: string
  downloads: number
  visible: boolean
  changelog: string | null
  createdAt: Date | null
}

export const Route = createFileRoute('/downloads')({
  component: DownloadsPage,
  head: () => ({
    meta: [
      { title: 'Downloads — Mineralz Purple PvP' },
      { name: 'description', content: 'Download Mineralz Purple PvP texture pack for Minecraft Bedrock and Java.' },
    ],
  }),
})

function ChestAnimation({ active }: { active: boolean }) {
  return (
    <div className={`fixed inset-0 z-50 flex items-center justify-center pointer-events-none transition-opacity duration-500 ${active ? 'opacity-100' : 'opacity-0'}`}>
      <div className="text-8xl" style={{ animation: active ? 'chestOpen 0.6s ease' : 'none', filter: 'drop-shadow(0 0 30px rgba(124,58,237,0.8))' }}>
        📦
      </div>
    </div>
  )
}

function PackCard({ pack, favorites, onFavorite, onDownload }: {
  pack: Pack
  favorites: number[]
  onFavorite: (id: number) => void
  onDownload: (pack: Pack) => void
}) {
  const isFav = favorites.includes(pack.id)
  const compat = pack.compatibility.split(',').filter(Boolean)

  return (
    <div className="glass-card rounded-2xl overflow-hidden transition-all duration-300 hover:-translate-y-1 group"
      style={{ boxShadow: 'none' }}
      onMouseEnter={e => (e.currentTarget.style.boxShadow = '0 12px 40px rgba(124,58,237,0.2)')}
      onMouseLeave={e => (e.currentTarget.style.boxShadow = 'none')}
    >
      {/* Thumbnail */}
      <div className="relative aspect-video bg-purple-950/40 overflow-hidden">
        {pack.thumbnail ? (
          <img src={pack.thumbnail} alt={pack.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <div className="text-6xl opacity-20">📦</div>
          </div>
        )}
        {/* Version badge */}
        <div className="absolute top-3 right-3 px-2.5 py-1 rounded-full text-xs font-bold text-purple-200"
          style={{ background: 'rgba(124,58,237,0.8)', border: '1px solid rgba(167,139,250,0.4)' }}>
          {pack.version}
        </div>
      </div>

      <div className="p-5">
        <div className="flex items-start justify-between mb-2">
          <h3 className="font-bold text-white text-lg leading-tight">{pack.name}</h3>
          <button
            onClick={() => onFavorite(pack.id)}
            className={`p-1.5 rounded-lg transition-all ${isFav ? 'text-pink-400' : 'text-gray-500 hover:text-pink-400'}`}
            aria-label="Toggle favorite"
          >
            <Heart size={16} fill={isFav ? 'currentColor' : 'none'} />
          </button>
        </div>

        <p className="text-gray-400 text-sm mb-4 leading-relaxed line-clamp-2">{pack.description}</p>

        {/* Compatibility badges */}
        <div className="flex items-center gap-2 mb-4 flex-wrap">
          {compat.map((c) => (
            <span key={c} className="px-2.5 py-1 rounded-full text-xs font-semibold capitalize"
              style={{ background: c === 'java' ? 'rgba(234,179,8,0.15)' : 'rgba(59,130,246,0.15)', color: c === 'java' ? '#fbbf24' : '#60a5fa', border: `1px solid ${c === 'java' ? 'rgba(234,179,8,0.3)' : 'rgba(59,130,246,0.3)'}` }}>
              {c === 'java' ? '☕ Java' : '🟢 Bedrock'}
            </span>
          ))}
        </div>

        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5 text-gray-500 text-xs">
            <Download size={12} />
            <span>{pack.downloads.toLocaleString()} downloads</span>
          </div>
          <button
            onClick={() => onDownload(pack)}
            className="glow-btn px-5 py-2.5 rounded-xl text-white font-semibold text-sm flex items-center gap-2"
          >
            <Download size={14} />
            Download
          </button>
        </div>
      </div>
    </div>
  )
}

function DownloadsPage() {
  const { user } = useIdentity()
  const [packs, setPacks] = useState<Pack[]>([])
  const [favorites, setFavorites] = useState<number[]>([])
  const [loading, setLoading] = useState(true)
  const [chestActive, setChestActive] = useState(false)

  useEffect(() => {
    async function load() {
      try {
        const [packsData, favsData] = await Promise.all([
          getPacks(),
          user ? getUserFavorites() : Promise.resolve([]),
        ])
        // If no packs exist yet, show default pack
        if (packsData.length === 0) {
          setPacks([{
            id: 1,
            name: 'Mineralz Purple PvP',
            version: 'v1.0',
            description: 'The ultimate PvP texture pack for Minecraft. Featuring 160+ optimized textures, sharper visuals, and smooth animations designed for competitive play.',
            downloadUrl: 'https://drive.google.com/uc?export=download&id=11B4i7_0KNS0N6MMu6QipXvmDA32EDjJz',
            thumbnail: null,
            compatibility: 'bedrock,java',
            downloads: 10247,
            visible: true,
            changelog: 'Initial release',
            createdAt: new Date(),
          }])
        } else {
          setPacks(packsData as Pack[])
        }
        setFavorites(favsData as number[])
      } catch (e) {
        console.error(e)
      } finally {
        setLoading(false)
      }
    }
    load()
  }, [user])

  async function handleDownload(pack: Pack) {
    setChestActive(true)
    setTimeout(() => setChestActive(false), 1500)
    try {
      await incrementDownload({ data: { packId: pack.id } })
      setPacks((prev) => prev.map((p) => p.id === pack.id ? { ...p, downloads: p.downloads + 1 } : p))
    } catch {}
    setTimeout(() => {
      window.open(pack.downloadUrl, '_blank')
    }, 600)
  }

  async function handleFavorite(packId: number) {
    if (!user) return
    try {
      const result = await toggleFavorite({ data: { packId } })
      if (result.favorited) {
        setFavorites((prev) => [...prev, packId])
      } else {
        setFavorites((prev) => prev.filter((id) => id !== packId))
      }
    } catch {}
  }

  return (
    <div className="min-h-screen">
      <ChestAnimation active={chestActive} />

      {/* Header */}
      <div className="relative py-24 text-center overflow-hidden"
        style={{ background: 'linear-gradient(180deg, rgba(124,58,237,0.1) 0%, transparent 100%)' }}>
        <div className="absolute inset-0 bg-grid opacity-20 pointer-events-none" />
        <div className="relative z-10 max-w-3xl mx-auto px-4">
          <p className="text-purple-400 text-sm font-semibold tracking-widest uppercase mb-3">Downloads</p>
          <h1 className="pixel-font text-2xl sm:text-3xl gradient-text mb-4">Get the Pack</h1>
          <p className="text-gray-400 max-w-lg mx-auto">
            Download Mineralz Purple PvP — compatible with Bedrock and Java. Always free, always updated.
          </p>
        </div>
      </div>

      {/* Packs grid */}
      <div className="max-w-6xl mx-auto px-4 pb-24">
        {loading ? (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1,2,3].map((i) => (
              <div key={i} className="glass-card rounded-2xl aspect-[3/4] animate-pulse" />
            ))}
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {packs.map((pack) => (
              <PackCard
                key={pack.id}
                pack={pack}
                favorites={favorites}
                onFavorite={handleFavorite}
                onDownload={handleDownload}
              />
            ))}
          </div>
        )}

        {!user && (
          <p className="text-center text-gray-500 text-sm mt-8">
            <a href="/login" className="text-purple-400 hover:text-purple-300">Sign in</a> to save favorites and track your downloads.
          </p>
        )}
      </div>
    </div>
  )
}
