import { createFileRoute } from '@tanstack/react-router'
import { Hero } from '../components/Hero'
import { StatsCounter } from '../components/StatsCounter'
import { FeaturesGrid } from '../components/FeaturesGrid'
import { ScreenshotGallery } from '../components/ScreenshotGallery'
import { FAQAccordion } from '../components/FAQAccordion'

export const Route = createFileRoute('/')({
  component: HomePage,
  head: () => ({
    meta: [
      { title: 'Mineralz Purple PvP — Ultimate Free Minecraft Texture Pack' },
      { name: 'description', content: 'Download the ultimate free Minecraft PvP texture pack. 160+ changes, Bedrock + Java, FPS optimized.' },
    ],
  }),
})

function HomePage() {
  return (
    <>
      <Hero />
      <StatsCounter />
      <FeaturesGrid />
      <ScreenshotGallery />
      <FAQAccordion />
    </>
  )
}
