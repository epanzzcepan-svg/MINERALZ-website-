import { createFileRoute, useNavigate } from '@tanstack/react-router'
import { useIdentity } from '../../lib/identity-context'
import { useEffect, useState } from 'react'
import { getAllPacks, createPack, updatePack, deletePack, togglePackVisibility, getDashboardStats } from '../../lib/packs'
import { ADMIN_EMAIL } from '../../lib/auth'
import { Plus, Edit, Trash2, Eye, EyeOff, Download, Package, BarChart2, X, Check } from 'lucide-react'

export const Route = createFileRoute('/admin/')({
  component: AdminPage,
  head: () => ({
    meta: [{ title: 'Admin Panel — Mineralz Purple PvP' }],
  }),
})

type Pack = {
  id: number
  name: string
  version: string
  description: string
  downloadUrl: string
  thumbnail: string | null
  compatibility: string
  downloads: number
  visible: boolean
  changelog: string | null
  createdAt: Date | null
}

type FormData = {
  name: string
  version: string
  description: string
  downloadUrl: string
  thumbnail: string
  compatibility: string
  changelog: string
  visible: boolean
}

const emptyForm: FormData = {
  name: '', version: '', description: '', downloadUrl: '',
  thumbnail: '', compatibility: 'bedrock,java', changelog: '', visible: true
}

function PackForm({ initial, onSave, onCancel, loading }: {
  initial: FormData
  onSave: (data: FormData) => void
  onCancel: () => void
  loading: boolean
}) {
  const [form, setForm] = useState(initial)
  const set = (k: keyof FormData, v: any) => setForm((f) => ({ ...f, [k]: v }))

  return (
    <div className="space-y-4">
      <div className="grid sm:grid-cols-2 gap-4">
        <div>
          <label className="text-gray-400 text-xs mb-1 block">Pack Name *</label>
          <input value={form.name} onChange={(e) => set('name', e.target.value)} required placeholder="Mineralz Purple PvP"
            className="w-full px-3 py-2.5 rounded-xl text-white text-sm outline-none"
            style={{ background: 'rgba(124,58,237,0.08)', border: '1px solid rgba(124,58,237,0.25)' }} />
        </div>
        <div>
          <label className="text-gray-400 text-xs mb-1 block">Version *</label>
          <input value={form.version} onChange={(e) => set('version', e.target.value)} required placeholder="v1.0"
            className="w-full px-3 py-2.5 rounded-xl text-white text-sm outline-none"
            style={{ background: 'rgba(124,58,237,0.08)', border: '1px solid rgba(124,58,237,0.25)' }} />
        </div>
      </div>
      <div>
        <label className="text-gray-400 text-xs mb-1 block">Description *</label>
        <textarea value={form.description} onChange={(e) => set('description', e.target.value)} required rows={3} placeholder="Pack description..."
          className="w-full px-3 py-2.5 rounded-xl text-white text-sm outline-none resize-none"
          style={{ background: 'rgba(124,58,237,0.08)', border: '1px solid rgba(124,58,237,0.25)' }} />
      </div>
      <div>
        <label className="text-gray-400 text-xs mb-1 block">Download URL *</label>
        <input value={form.downloadUrl} onChange={(e) => set('downloadUrl', e.target.value)} required placeholder="https://drive.google.com/..."
          className="w-full px-3 py-2.5 rounded-xl text-white text-sm outline-none"
          style={{ background: 'rgba(124,58,237,0.08)', border: '1px solid rgba(124,58,237,0.25)' }} />
      </div>
      <div>
        <label className="text-gray-400 text-xs mb-1 block">Thumbnail URL</label>
        <input value={form.thumbnail} onChange={(e) => set('thumbnail', e.target.value)} placeholder="https://..."
          className="w-full px-3 py-2.5 rounded-xl text-white text-sm outline-none"
          style={{ background: 'rgba(124,58,237,0.08)', border: '1px solid rgba(124,58,237,0.25)' }} />
      </div>
      <div className="grid sm:grid-cols-2 gap-4">
        <div>
          <label className="text-gray-400 text-xs mb-2 block">Compatibility</label>
          <div className="flex gap-3">
            {['bedrock', 'java'].map((c) => (
              <label key={c} className="flex items-center gap-2 text-sm text-gray-300 cursor-pointer">
                <input type="checkbox"
                  checked={form.compatibility.includes(c)}
                  onChange={(e) => {
                    const parts = form.compatibility.split(',').filter(Boolean)
                    if (e.target.checked) set('compatibility', [...parts, c].join(','))
                    else set('compatibility', parts.filter((p) => p !== c).join(','))
                  }}
                  className="accent-purple-500" />
                <span className="capitalize">{c}</span>
              </label>
            ))}
          </div>
        </div>
        <div>
          <label className="text-gray-400 text-xs mb-2 block">Visibility</label>
          <label className="flex items-center gap-2 text-sm text-gray-300 cursor-pointer">
            <input type="checkbox" checked={form.visible} onChange={(e) => set('visible', e.target.checked)} className="accent-purple-500" />
            Visible to public
          </label>
        </div>
      </div>
      <div>
        <label className="text-gray-400 text-xs mb-1 block">Changelog</label>
        <textarea value={form.changelog} onChange={(e) => set('changelog', e.target.value)} rows={3} placeholder="What's new..."
          className="w-full px-3 py-2.5 rounded-xl text-white text-sm outline-none resize-none"
          style={{ background: 'rgba(124,58,237,0.08)', border: '1px solid rgba(124,58,237,0.25)' }} />
      </div>
      <div className="flex justify-end gap-3 pt-2">
        <button onClick={onCancel} className="px-4 py-2 rounded-xl text-gray-400 hover:text-white text-sm transition-colors"
          style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)' }}>
          Cancel
        </button>
        <button onClick={() => onSave(form)} disabled={loading}
          className="glow-btn px-6 py-2 rounded-xl text-white font-semibold text-sm flex items-center gap-2">
          {loading ? <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" /> : <Check size={14} />}
          Save Pack
        </button>
      </div>
    </div>
  )
}

function AdminPage() {
  const { user, ready } = useIdentity()
  const navigate = useNavigate()
  const [packs, setPacks] = useState<Pack[]>([])
  const [stats, setStats] = useState({ totalPacks: 0, totalDownloads: 0 })
  const [loading, setLoading] = useState(true)
  const [modal, setModal] = useState<'create' | 'edit' | null>(null)
  const [editPack, setEditPack] = useState<Pack | null>(null)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState('')

  useEffect(() => {
    if (ready && (!user || user.email !== ADMIN_EMAIL)) {
      navigate({ to: '/' })
    }
  }, [ready, user, navigate])

  useEffect(() => {
    if (!user || user.email !== ADMIN_EMAIL) return
    async function load() {
      try {
        const [packsData, statsData] = await Promise.all([getAllPacks(), getDashboardStats()])
        setPacks(packsData as Pack[])
        setStats(statsData as any)
      } catch (e: any) {
        setError(e.message)
      } finally {
        setLoading(false)
      }
    }
    load()
  }, [user])

  async function handleCreate(form: FormData) {
    setSaving(true)
    try {
      await createPack({ data: form })
      const updated = await getAllPacks()
      setPacks(updated as Pack[])
      setModal(null)
    } catch (e: any) { setError(e.message) }
    finally { setSaving(false) }
  }

  async function handleEdit(form: FormData) {
    if (!editPack) return
    setSaving(true)
    try {
      await updatePack({ data: { id: editPack.id, ...form } })
      const updated = await getAllPacks()
      setPacks(updated as Pack[])
      setModal(null)
      setEditPack(null)
    } catch (e: any) { setError(e.message) }
    finally { setSaving(false) }
  }

  async function handleDelete(id: number) {
    if (!confirm('Delete this pack? This cannot be undone.')) return
    try {
      await deletePack({ data: { id } })
      setPacks((prev) => prev.filter((p) => p.id !== id))
    } catch (e: any) { setError(e.message) }
  }

  async function handleToggleVisible(pack: Pack) {
    try {
      await togglePackVisibility({ data: { id: pack.id, visible: !pack.visible } })
      setPacks((prev) => prev.map((p) => p.id === pack.id ? { ...p, visible: !p.visible } : p))
    } catch (e: any) { setError(e.message) }
  }

  if (!ready || !user || user.email !== ADMIN_EMAIL) return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="w-8 h-8 border-2 border-purple-500 border-t-transparent rounded-full animate-spin" />
    </div>
  )

  return (
    <div className="min-h-screen">
      {/* Header */}
      <div className="relative py-16 overflow-hidden" style={{ background: 'linear-gradient(180deg, rgba(234,179,8,0.08) 0%, transparent 100%)' }}>
        <div className="absolute inset-0 bg-grid opacity-20 pointer-events-none" />
        <div className="relative z-10 max-w-6xl mx-auto px-4">
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div>
              <p className="text-yellow-500 text-xs font-semibold tracking-widest uppercase mb-2">Admin Panel</p>
              <h1 className="pixel-font text-xl sm:text-2xl text-yellow-300">Dashboard</h1>
              <p className="text-gray-500 text-sm mt-1">{user.email}</p>
            </div>
            <button
              onClick={() => setModal('create')}
              className="flex items-center gap-2 px-5 py-3 rounded-xl font-semibold text-sm text-white"
              style={{ background: 'linear-gradient(135deg, #7c3aed, #6d28d9)', boxShadow: '0 0 20px rgba(124,58,237,0.4)' }}
            >
              <Plus size={16} />
              Add Pack
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 pb-24">
        {/* Stats */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 mb-8">
          {[
            { icon: Package, label: 'Total Packs', value: packs.length },
            { icon: Download, label: 'Total Downloads', value: (stats.totalDownloads + packs.reduce((s, p) => s + p.downloads, 0)).toLocaleString() },
            { icon: BarChart2, label: 'Public Packs', value: packs.filter((p) => p.visible).length },
          ].map((s) => {
            const Icon = s.icon
            return (
              <div key={s.label} className="glass-card rounded-2xl p-5 text-center">
                <Icon size={20} className="text-purple-400 mx-auto mb-2" />
                <div className="text-2xl font-bold text-white">{s.value}</div>
                <div className="text-gray-500 text-xs mt-1">{s.label}</div>
              </div>
            )
          })}
        </div>

        {error && (
          <div className="glass-card rounded-xl p-4 mb-6 text-red-400 text-sm border border-red-500/30">{error}</div>
        )}

        {/* Packs table */}
        <div className="glass-card rounded-2xl overflow-hidden">
          <div className="px-6 py-4 border-b" style={{ borderColor: 'rgba(124,58,237,0.2)' }}>
            <h2 className="font-bold text-white">Pack Management</h2>
          </div>

          {loading ? (
            <div className="p-8 flex justify-center">
              <div className="w-6 h-6 border-2 border-purple-500 border-t-transparent rounded-full animate-spin" />
            </div>
          ) : packs.length === 0 ? (
            <div className="p-12 text-center text-gray-500">
              No packs yet. Add your first pack above.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr style={{ borderBottom: '1px solid rgba(124,58,237,0.15)' }}>
                    {['Name', 'Version', 'Compat', 'Downloads', 'Status', 'Actions'].map((h) => (
                      <th key={h} className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wide">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {packs.map((pack) => (
                    <tr key={pack.id} className="transition-colors hover:bg-purple-900/10" style={{ borderBottom: '1px solid rgba(124,58,237,0.08)' }}>
                      <td className="px-4 py-4 font-medium text-white text-sm">{pack.name}</td>
                      <td className="px-4 py-4 text-gray-400 text-sm">{pack.version}</td>
                      <td className="px-4 py-4 text-gray-400 text-xs">{pack.compatibility}</td>
                      <td className="px-4 py-4 text-gray-400 text-sm">{pack.downloads.toLocaleString()}</td>
                      <td className="px-4 py-4">
                        <span className={`px-2 py-1 rounded-full text-xs font-semibold ${pack.visible ? 'text-green-300' : 'text-gray-500'}`}
                          style={{ background: pack.visible ? 'rgba(34,197,94,0.1)' : 'rgba(107,114,128,0.1)' }}>
                          {pack.visible ? 'Public' : 'Hidden'}
                        </span>
                      </td>
                      <td className="px-4 py-4">
                        <div className="flex items-center gap-2">
                          <button onClick={() => handleToggleVisible(pack)} title={pack.visible ? 'Hide' : 'Show'}
                            className="p-1.5 rounded-lg text-gray-400 hover:text-purple-300 transition-colors"
                            style={{ background: 'rgba(124,58,237,0.1)' }}>
                            {pack.visible ? <Eye size={14} /> : <EyeOff size={14} />}
                          </button>
                          <button onClick={() => { setEditPack(pack); setModal('edit') }} title="Edit"
                            className="p-1.5 rounded-lg text-gray-400 hover:text-blue-300 transition-colors"
                            style={{ background: 'rgba(59,130,246,0.1)' }}>
                            <Edit size={14} />
                          </button>
                          <button onClick={() => handleDelete(pack.id)} title="Delete"
                            className="p-1.5 rounded-lg text-gray-400 hover:text-red-300 transition-colors"
                            style={{ background: 'rgba(239,68,68,0.1)' }}>
                            <Trash2 size={14} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {/* Modal */}
      {modal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4"
          style={{ background: 'rgba(0,0,0,0.8)', backdropFilter: 'blur(12px)' }}>
          <div className="glass-card rounded-3xl w-full max-w-2xl max-h-[90vh] overflow-y-auto"
            style={{ boxShadow: '0 40px 100px rgba(124,58,237,0.3)' }}>
            <div className="flex items-center justify-between px-6 py-5 border-b" style={{ borderColor: 'rgba(124,58,237,0.2)' }}>
              <h3 className="font-bold text-white">{modal === 'create' ? 'Add New Pack' : 'Edit Pack'}</h3>
              <button onClick={() => { setModal(null); setEditPack(null) }} className="p-1.5 rounded-lg text-gray-400 hover:text-white transition-colors">
                <X size={18} />
              </button>
            </div>
            <div className="p-6">
              <PackForm
                initial={editPack ? {
                  name: editPack.name,
                  version: editPack.version,
                  description: editPack.description,
                  downloadUrl: editPack.downloadUrl,
                  thumbnail: editPack.thumbnail || '',
                  compatibility: editPack.compatibility,
                  changelog: editPack.changelog || '',
                  visible: editPack.visible,
                } : emptyForm}
                onSave={modal === 'create' ? handleCreate : handleEdit}
                onCancel={() => { setModal(null); setEditPack(null) }}
                loading={saving}
              />
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
