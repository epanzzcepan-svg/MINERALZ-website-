import { createFileRoute } from '@tanstack/react-router'

const CHANGELOG = [
  {
    version: 'v1.0',
    date: 'May 2026',
    label: 'Initial Release',
    changes: [
      'PvP optimized textures across all weapon types',
      'Bedrock Edition full support',
      'Java Edition full support',
      'Complete UI overhaul — HUD, inventory, menus',
      'Performance optimization — reduced texture complexity for FPS gains',
      'Custom enchantment glint (purple)',
      '160+ individual texture changes',
      'Sharper hit indicators and damage animations',
    ],
    isLatest: true,
  },
]

export const Route = createFileRoute('/changelog')({
  component: ChangelogPage,
  head: () => ({
    meta: [
      { title: 'Changelog — Mineralz Purple PvP' },
      { name: 'description', content: 'Release history and updates for Mineralz Purple PvP texture pack.' },
    ],
  }),
})

function ChangelogPage() {
  return (
    <div className="min-h-screen">
      {/* Header */}
      <div className="relative py-24 text-center overflow-hidden"
        style={{ background: 'linear-gradient(180deg, rgba(124,58,237,0.1) 0%, transparent 100%)' }}>
        <div className="absolute inset-0 bg-grid opacity-20 pointer-events-none" />
        <div className="relative z-10 max-w-3xl mx-auto px-4">
          <p className="text-purple-400 text-sm font-semibold tracking-widest uppercase mb-3">History</p>
          <h1 className="pixel-font text-2xl sm:text-3xl gradient-text mb-4">Changelog</h1>
          <p className="text-gray-400">Every update, every improvement — tracked and documented.</p>
        </div>
      </div>

      <div className="max-w-2xl mx-auto px-4 pb-24">
        <div className="relative">
          {/* Timeline vertical line */}
          <div className="absolute left-4 top-0 bottom-0 w-0.5" style={{ background: 'linear-gradient(to bottom, #7c3aed, transparent)' }} />

          {CHANGELOG.map((entry, i) => (
            <div key={i} className="pl-12 pb-12 relative">
              {/* Timeline dot */}
              <div className="absolute left-0 top-1 w-8 h-8 rounded-full flex items-center justify-center"
                style={{ background: 'rgba(124,58,237,0.2)', border: '2px solid #7c3aed', boxShadow: '0 0 12px rgba(124,58,237,0.4)' }}>
                <div className="w-2 h-2 rounded-full bg-purple-400" />
              </div>

              <div className="glass-card rounded-2xl p-6">
                <div className="flex items-center gap-3 mb-4 flex-wrap">
                  <h2 className="pixel-font text-lg text-purple-300">{entry.version}</h2>
                  {entry.isLatest && (
                    <span className="px-2.5 py-1 rounded-full text-xs font-bold text-green-300"
                      style={{ background: 'rgba(34,197,94,0.15)', border: '1px solid rgba(34,197,94,0.3)' }}>
                      Latest
                    </span>
                  )}
                  <span className="text-gray-500 text-sm ml-auto">{entry.date}</span>
                </div>
                <h3 className="font-bold text-white mb-4">{entry.label}</h3>
                <ul className="space-y-2">
                  {entry.changes.map((change, j) => (
                    <li key={j} className="flex items-start gap-2 text-gray-400 text-sm">
                      <span className="text-purple-500 mt-0.5 flex-shrink-0">▸</span>
                      {change}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
