import { createFileRoute } from '@tanstack/react-router'
import { useState } from 'react'
import { CheckCircle, Circle } from 'lucide-react'

type Platform = 'bedrock' | 'java'

const STEPS: Record<Platform, { title: string; desc: string }[]> = {
  bedrock: [
    { title: 'Download the Pack', desc: 'Click the Download button on the Downloads page to get the .mcpack file.' },
    { title: 'Open the File', desc: 'Tap or double-click the downloaded .mcpack file. Minecraft will open automatically and begin importing.' },
    { title: 'Wait for Import', desc: 'You\'ll see "Pack importing" at the top of your screen. This takes 2–5 seconds.' },
    { title: 'Activate in Settings', desc: 'Go to Settings → Global Resources. You\'ll see Mineralz Purple PvP listed. Tap it and hit Activate.' },
    { title: 'Start Playing!', desc: 'Launch any world or server. Your textures are now active. Press F3+T to reload if needed.' },
  ],
  java: [
    { title: 'Download the Pack', desc: 'Click the Download button on the Downloads page to get the .zip file.' },
    { title: 'Open Resource Packs Folder', desc: 'In Minecraft Java, go to Options → Resource Packs → Open Pack Folder. This opens the resourcepacks directory.' },
    { title: 'Move the File', desc: 'Drag and drop the downloaded .zip file into the resourcepacks folder. Do not extract it.' },
    { title: 'Activate the Pack', desc: 'Back in Minecraft, click the pack to move it to the "Selected" side, then click Done.' },
    { title: 'Start Playing!', desc: 'Your textures load immediately. If something looks off, press F3+T to force reload all resources.' },
  ],
}

export const Route = createFileRoute('/installation')({
  component: InstallationPage,
  head: () => ({
    meta: [
      { title: 'Installation Guide — Mineralz Purple PvP' },
      { name: 'description', content: 'Step-by-step guide to install Mineralz Purple PvP on Bedrock and Java Minecraft.' },
    ],
  }),
})

function StepItem({ step, index, isComplete, onClick }: {
  step: { title: string; desc: string }
  index: number
  isComplete: boolean
  onClick: () => void
}) {
  return (
    <div className="flex gap-4 cursor-pointer group" onClick={onClick}>
      <div className="flex flex-col items-center">
        <div className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 transition-all duration-300 ${isComplete ? 'bg-green-500/20 border-green-500/50' : 'bg-purple-900/30 border-purple-500/30'} border`}
          style={{ boxShadow: isComplete ? '0 0 16px rgba(34,197,94,0.3)' : 'none' }}>
          {isComplete ? (
            <CheckCircle size={18} className="text-green-400" />
          ) : (
            <span className="text-purple-400 text-sm font-bold pixel-font">{index + 1}</span>
          )}
        </div>
        {index < 4 && (
          <div className="w-0.5 flex-1 mt-1" style={{
            background: isComplete ? 'rgba(34,197,94,0.4)' : 'rgba(124,58,237,0.2)',
            minHeight: 32,
            transition: 'background 0.3s',
          }} />
        )}
      </div>
      <div className={`glass-card rounded-xl p-5 flex-1 mb-4 transition-all duration-300 ${isComplete ? 'border-green-500/30' : ''} group-hover:border-purple-500/40`}>
        <h3 className={`font-bold mb-1.5 text-base transition-colors ${isComplete ? 'text-green-300' : 'text-white'}`}>
          {step.title}
        </h3>
        <p className="text-gray-400 text-sm leading-relaxed">{step.desc}</p>
      </div>
    </div>
  )
}

function InstallationPage() {
  const [platform, setPlatform] = useState<Platform>('bedrock')
  const [completed, setCompleted] = useState<Set<number>>(new Set())

  function toggleStep(i: number) {
    setCompleted((prev) => {
      const next = new Set(prev)
      if (next.has(i)) next.delete(i)
      else next.add(i)
      return next
    })
  }

  const steps = STEPS[platform]
  const progress = (completed.size / steps.length) * 100

  return (
    <div className="min-h-screen">
      {/* Header */}
      <div className="relative py-24 text-center overflow-hidden"
        style={{ background: 'linear-gradient(180deg, rgba(124,58,237,0.1) 0%, transparent 100%)' }}>
        <div className="absolute inset-0 bg-grid opacity-20 pointer-events-none" />
        <div className="relative z-10 max-w-3xl mx-auto px-4">
          <p className="text-purple-400 text-sm font-semibold tracking-widest uppercase mb-3">Get Started</p>
          <h1 className="pixel-font text-2xl sm:text-3xl gradient-text mb-4">Installation Guide</h1>
          <p className="text-gray-400">Follow these steps to get Mineralz Purple PvP running in minutes.</p>
        </div>
      </div>

      <div className="max-w-2xl mx-auto px-4 pb-24">
        {/* Platform tabs */}
        <div className="flex rounded-xl overflow-hidden mb-8 p-1"
          style={{ background: 'rgba(124,58,237,0.1)', border: '1px solid rgba(124,58,237,0.2)' }}>
          {(['bedrock', 'java'] as Platform[]).map((p) => (
            <button
              key={p}
              onClick={() => { setPlatform(p); setCompleted(new Set()) }}
              className={`flex-1 py-3 rounded-lg font-semibold text-sm transition-all duration-200 capitalize ${platform === p ? 'text-white' : 'text-gray-400 hover:text-purple-300'}`}
              style={platform === p ? { background: 'linear-gradient(135deg, #7c3aed, #6d28d9)', boxShadow: '0 0 16px rgba(124,58,237,0.4)' } : {}}
            >
              {p === 'bedrock' ? '🟢 Bedrock Edition' : '☕ Java Edition'}
            </button>
          ))}
        </div>

        {/* Progress bar */}
        <div className="mb-8">
          <div className="flex justify-between text-xs text-gray-500 mb-2">
            <span>Progress</span>
            <span>{completed.size}/{steps.length} steps</span>
          </div>
          <div className="h-2 rounded-full overflow-hidden" style={{ background: 'rgba(124,58,237,0.15)' }}>
            <div className="h-full rounded-full transition-all duration-500"
              style={{ width: `${progress}%`, background: 'linear-gradient(90deg, #7c3aed, #a78bfa)', boxShadow: '0 0 8px rgba(124,58,237,0.6)' }} />
          </div>
        </div>

        {/* Steps */}
        <div>
          {steps.map((step, i) => (
            <StepItem
              key={`${platform}-${i}`}
              step={step}
              index={i}
              isComplete={completed.has(i)}
              onClick={() => toggleStep(i)}
            />
          ))}
        </div>

        {completed.size === steps.length && (
          <div className="text-center py-8 glass-card rounded-2xl mt-4"
            style={{ borderColor: 'rgba(34,197,94,0.4)', boxShadow: '0 0 30px rgba(34,197,94,0.1)' }}>
            <div className="text-4xl mb-3">🎉</div>
            <h3 className="pixel-font text-sm text-green-300 mb-2">You're all set!</h3>
            <p className="text-gray-400 text-sm">Time to dominate. Good luck on the battlefield.</p>
          </div>
        )}

        {/* Download CTA */}
        <div className="mt-10 text-center">
          <a
            href="https://drive.google.com/uc?export=download&id=11B4i7_0KNS0N6MMu6QipXvmDA32EDjJz"
            className="glow-btn inline-flex items-center gap-2 px-8 py-4 rounded-xl text-white font-bold"
          >
            Download Mineralz PvP
          </a>
        </div>
      </div>
    </div>
  )
}
