import { createFileRoute } from '@tanstack/react-router'
import { FAQAccordion } from '../components/FAQAccordion'

export const Route = createFileRoute('/faq')({
  component: FAQPage,
  head: () => ({
    meta: [
      { title: 'FAQ — Mineralz Purple PvP' },
      { name: 'description', content: 'Frequently asked questions about Mineralz Purple PvP Minecraft texture pack.' },
    ],
  }),
})

function FAQPage() {
  return (
    <div className="min-h-screen">
      {/* Header */}
      <div className="relative py-24 text-center overflow-hidden"
        style={{ background: 'linear-gradient(180deg, rgba(124,58,237,0.1) 0%, transparent 100%)' }}>
        <div className="absolute inset-0 bg-grid opacity-20 pointer-events-none" />
        <div className="relative z-10 max-w-3xl mx-auto px-4">
          <p className="text-purple-400 text-sm font-semibold tracking-widest uppercase mb-3">Support</p>
          <h1 className="pixel-font text-2xl sm:text-3xl gradient-text mb-4">FAQ</h1>
          <p className="text-gray-400">Everything you need to know about Mineralz Purple PvP.</p>
        </div>
      </div>
      <FAQAccordion />
    </div>
  )
}
