import { createRootRoute, HeadContent, Outlet, Scripts } from '@tanstack/react-router'
import { Navbar } from '../components/Navbar'
import { Footer } from '../components/Footer'
import { FloatingActions } from '../components/FloatingActions'
import { CallbackHandler } from '../components/CallbackHandler'
import { IdentityProvider } from '../lib/identity-context'
import '../styles.css'

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: 'utf-8' },
      { name: 'viewport', content: 'width=device-width, initial-scale=1' },
      { title: 'Mineralz Purple PvP — Ultimate Minecraft Texture Pack' },
      { name: 'description', content: 'The ultimate free PvP texture pack for Minecraft. 160+ texture changes, Bedrock & Java support. Download now.' },
      { name: 'keywords', content: 'Minecraft PvP texture pack, Bedrock, Java, free, Mineralz Purple' },
      { property: 'og:title', content: 'Mineralz Purple PvP' },
      { property: 'og:description', content: 'The ultimate free Minecraft PvP texture pack — 160+ changes, Bedrock + Java.' },
      { property: 'og:type', content: 'website' },
      { property: 'og:image', content: '/og-image.png' },
      { name: 'twitter:card', content: 'summary_large_image' },
      { name: 'twitter:title', content: 'Mineralz Purple PvP' },
      { name: 'twitter:description', content: 'The ultimate free Minecraft PvP texture pack.' },
      { name: 'theme-color', content: '#7c3aed' },
    ],
    links: [
      { rel: 'icon', href: '/favicon.ico' },
      { rel: 'preconnect', href: 'https://fonts.googleapis.com' },
      { rel: 'preconnect', href: 'https://fonts.gstatic.com', crossOrigin: '' },
    ],
  }),
  shellComponent: RootDocument,
  component: () => <Outlet />,
})

function RootDocument({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <HeadContent />
      </head>
      <body>
        <IdentityProvider>
          <CallbackHandler>
            <Navbar />
            <main className="page-enter">{children}</main>
            <Footer />
            <FloatingActions />
          </CallbackHandler>
        </IdentityProvider>
        <Scripts />
      </body>
    </html>
  )
}
