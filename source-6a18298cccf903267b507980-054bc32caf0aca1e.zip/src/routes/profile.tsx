import { createFileRoute, useNavigate, useSearch } from '@tanstack/react-router'
import { useIdentity } from '../lib/identity-context'
import { useEffect, useState } from 'react'
import { getDownloadHistory, getUserFavorites, getPacks } from '../lib/packs'
import { Heart, Download, User, Clock } from 'lucide-react'
import { z } from 'zod'

const searchSchema = z.object({ tab: z.string().optional() })

export const Route = createFileRoute('/profile')({
  component: ProfilePage,
  validateSearch: searchSchema,
  head: () => ({
    meta: [{ title: 'Profile — Mineralz Purple PvP' }],
  }),
})

function ProfilePage() {
  const { user, ready, logout } = useIdentity()
  const navigate = useNavigate()
  const search = useSearch({ from: '/profile' })
  const [activeTab, setActiveTab] = useState(search.tab || 'profile')
  const [history, setHistory] = useState<any[]>([])
  const [favPackIds, setFavPackIds] = useState<number[]>([])
  const [favPacks, setFavPacks] = useState<any[]>([])

  useEffect(() => {
    if (ready && !user) navigate({ to: '/login' })
  }, [ready, user, navigate])

  useEffect(() => {
    if (!user) return
    getDownloadHistory().then(setHistory).catch(console.error)
    getUserFavorites().then((ids) => {
      setFavPackIds(ids as number[])
      getPacks().then((packs: any[]) => {
        setFavPacks(packs.filter((p) => (ids as number[]).includes(p.id)))
      }).catch(console.error)
    }).catch(console.error)
  }, [user])

  if (!ready || !user) return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="w-8 h-8 border-2 border-purple-500 border-t-transparent rounded-full animate-spin" />
    </div>
  )

  const tabs = [
    { id: 'profile', label: 'Profile', icon: User },
    { id: 'favorites', label: 'Favorites', icon: Heart },
    { id: 'history', label: 'Downloads', icon: Download },
  ]

  return (
    <div className="min-h-screen">
      {/* Header */}
      <div className="relative py-20 overflow-hidden" style={{ background: 'linear-gradient(180deg, rgba(124,58,237,0.1) 0%, transparent 100%)' }}>
        <div className="absolute inset-0 bg-grid opacity-20 pointer-events-none" />
        <div className="relative z-10 max-w-4xl mx-auto px-4 flex items-center gap-6">
          {user.pictureUrl ? (
            <img src={user.pictureUrl} alt={user.name} className="w-20 h-20 rounded-2xl border-2 border-purple-500/40" />
          ) : (
            <div className="w-20 h-20 rounded-2xl flex items-center justify-center text-white text-3xl font-bold"
              style={{ background: 'linear-gradient(135deg, #7c3aed, #a78bfa)', border: '2px solid rgba(167,139,250,0.4)' }}>
              {(user.name || user.email || 'U')[0].toUpperCase()}
            </div>
          )}
          <div>
            <h1 className="text-2xl font-bold text-white">{user.name || 'Player'}</h1>
            <p className="text-gray-400 text-sm">{user.email}</p>
            <div className="flex items-center gap-2 mt-2">
              <span className="px-2.5 py-1 rounded-full text-xs font-semibold text-purple-300"
                style={{ background: 'rgba(124,58,237,0.2)', border: '1px solid rgba(124,58,237,0.3)' }}>
                Member
              </span>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 pb-24">
        {/* Tabs */}
        <div className="flex gap-1 mb-8 p-1 rounded-xl w-fit"
          style={{ background: 'rgba(124,58,237,0.1)', border: '1px solid rgba(124,58,237,0.2)' }}>
          {tabs.map((tab) => {
            const Icon = tab.icon
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-semibold transition-all ${activeTab === tab.id ? 'text-white' : 'text-gray-400 hover:text-purple-300'}`}
                style={activeTab === tab.id ? { background: 'linear-gradient(135deg, #7c3aed, #6d28d9)', boxShadow: '0 0 12px rgba(124,58,237,0.4)' } : {}}
              >
                <Icon size={14} />
                {tab.label}
              </button>
            )
          })}
        </div>

        {/* Content */}
        {activeTab === 'profile' && (
          <div className="glass-card rounded-2xl p-6 max-w-md">
            <h2 className="font-bold text-white text-lg mb-6">Account Info</h2>
            <div className="space-y-4">
              <div>
                <label className="text-gray-500 text-xs uppercase tracking-wide mb-1 block">Display Name</label>
                <p className="text-white font-medium">{user.name || '—'}</p>
              </div>
              <div>
                <label className="text-gray-500 text-xs uppercase tracking-wide mb-1 block">Email</label>
                <p className="text-white font-medium">{user.email}</p>
              </div>
              <div>
                <label className="text-gray-500 text-xs uppercase tracking-wide mb-1 block">Downloads</label>
                <p className="text-white font-medium">{history.length}</p>
              </div>
            </div>
            <button
              onClick={() => { logout(); navigate({ to: '/' }) }}
              className="mt-8 px-4 py-2 rounded-xl text-sm text-red-400 hover:text-red-300 transition-colors"
              style={{ background: 'rgba(239,68,68,0.1)', border: '1px solid rgba(239,68,68,0.2)' }}
            >
              Log Out
            </button>
          </div>
        )}

        {activeTab === 'favorites' && (
          <div>
            <h2 className="font-bold text-white text-lg mb-6">Favorited Packs</h2>
            {favPacks.length === 0 ? (
              <div className="glass-card rounded-2xl p-12 text-center">
                <Heart size={40} className="text-gray-600 mx-auto mb-3" />
                <p className="text-gray-500">No favorites yet. Browse the downloads page to save packs.</p>
              </div>
            ) : (
              <div className="grid sm:grid-cols-2 gap-4">
                {favPacks.map((pack) => (
                  <div key={pack.id} className="glass-card rounded-2xl p-5 flex items-center gap-4">
                    <div className="w-14 h-14 rounded-xl bg-purple-900/40 flex items-center justify-center text-2xl">📦</div>
                    <div className="flex-1">
                      <p className="font-bold text-white text-sm">{pack.name}</p>
                      <p className="text-gray-400 text-xs">{pack.version}</p>
                    </div>
                    <a href={pack.downloadUrl} target="_blank" rel="noopener noreferrer"
                      className="p-2 rounded-lg text-purple-400 hover:text-purple-300 transition-colors"
                      style={{ background: 'rgba(124,58,237,0.1)' }}>
                      <Download size={16} />
                    </a>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {activeTab === 'history' && (
          <div>
            <h2 className="font-bold text-white text-lg mb-6">Download History</h2>
            {history.length === 0 ? (
              <div className="glass-card rounded-2xl p-12 text-center">
                <Download size={40} className="text-gray-600 mx-auto mb-3" />
                <p className="text-gray-500">No downloads recorded yet.</p>
              </div>
            ) : (
              <div className="space-y-3">
                {history.map((log) => (
                  <div key={log.id} className="glass-card rounded-xl px-5 py-4 flex items-center gap-4">
                    <div className="w-10 h-10 rounded-lg bg-purple-900/40 flex items-center justify-center text-lg">📦</div>
                    <div className="flex-1">
                      <p className="font-semibold text-white text-sm">{log.packName}</p>
                      <p className="text-gray-500 text-xs">{log.packVersion}</p>
                    </div>
                    <div className="flex items-center gap-1.5 text-gray-600 text-xs">
                      <Clock size={12} />
                      {new Date(log.downloadedAt).toLocaleDateString()}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
