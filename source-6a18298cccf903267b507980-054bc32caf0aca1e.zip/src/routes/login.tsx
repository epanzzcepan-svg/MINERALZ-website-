import { createFileRoute, useNavigate, Link } from '@tanstack/react-router'
import { login, signup, oauthLogin } from '@netlify/identity'
import { useIdentity } from '../lib/identity-context'
import { useState, useEffect } from 'react'
import { Github, Mail, Eye, EyeOff, ArrowRight } from 'lucide-react'

export const Route = createFileRoute('/login')({
  component: LoginPage,
  head: () => ({
    meta: [{ title: 'Login — Mineralz Purple PvP' }],
  }),
})

type Mode = 'login' | 'signup' | 'confirm'

function LoginPage() {
  const { user, ready } = useIdentity()
  const navigate = useNavigate()
  const [mode, setMode] = useState<Mode>('login')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [name, setName] = useState('')
  const [showPass, setShowPass] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  useEffect(() => {
    if (ready && user) navigate({ to: '/' })
  }, [ready, user, navigate])

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setError('')
    setLoading(true)
    try {
      if (mode === 'login') {
        await login(email, password)
        navigate({ to: '/' })
      } else {
        await signup(email, password, { full_name: name })
        setMode('confirm')
      }
    } catch (err: any) {
      setError(err.message || 'Something went wrong')
    } finally {
      setLoading(false)
    }
  }

  if (!ready) return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="w-8 h-8 border-2 border-purple-500 border-t-transparent rounded-full animate-spin" />
    </div>
  )

  return (
    <div className="min-h-screen flex items-center justify-center px-4 py-24">
      {/* Background */}
      <div className="absolute inset-0 bg-grid opacity-20 pointer-events-none" />
      <div className="absolute inset-0 pointer-events-none" style={{
        background: 'radial-gradient(ellipse 50% 60% at 50% 40%, rgba(124,58,237,0.1) 0%, transparent 70%)'
      }} />

      <div className="relative w-full max-w-md">
        {/* Card */}
        <div className="glass-card rounded-3xl p-8" style={{ boxShadow: '0 30px 80px rgba(124,58,237,0.15)' }}>
          {/* Logo */}
          <div className="text-center mb-8">
            <div className="w-12 h-12 rounded-xl mx-auto mb-4 flex items-center justify-center pixel-font text-white text-xl"
              style={{ background: 'linear-gradient(135deg, #7c3aed, #a78bfa)', boxShadow: '0 0 20px rgba(124,58,237,0.5)' }}>
              M
            </div>
            <h1 className="pixel-font text-sm gradient-text mb-1">
              {mode === 'confirm' ? 'Check your email' : mode === 'login' ? 'Welcome back' : 'Create account'}
            </h1>
            <p className="text-gray-500 text-xs mt-2">
              {mode === 'confirm'
                ? `We sent a confirmation to ${email}`
                : mode === 'login'
                ? 'Sign in to your Mineralz account'
                : 'Join the Mineralz community'}
            </p>
          </div>

          {mode === 'confirm' ? (
            <div className="text-center py-4">
              <div className="text-5xl mb-4">📧</div>
              <p className="text-gray-400 text-sm leading-relaxed mb-6">
                Click the link in your email to confirm your account. Then you can log in.
              </p>
              <button onClick={() => setMode('login')} className="glow-btn px-6 py-3 rounded-xl text-white font-semibold text-sm">
                Back to Login
              </button>
            </div>
          ) : (
            <>
              {/* OAuth buttons */}
              <div className="space-y-3 mb-6">
                <button
                  onClick={() => oauthLogin('github')}
                  className="w-full flex items-center justify-center gap-3 py-3 rounded-xl font-semibold text-sm text-white transition-all hover:-translate-y-0.5"
                  style={{ background: 'rgba(255,255,255,0.08)', border: '1px solid rgba(255,255,255,0.12)' }}
                >
                  <Github size={18} />
                  Continue with GitHub
                </button>
                <button
                  onClick={() => oauthLogin('google')}
                  className="w-full flex items-center justify-center gap-3 py-3 rounded-xl font-semibold text-sm text-white transition-all hover:-translate-y-0.5"
                  style={{ background: 'rgba(255,255,255,0.08)', border: '1px solid rgba(255,255,255,0.12)' }}
                >
                  <svg width="18" height="18" viewBox="0 0 24 24"><path fill="#4285f4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/><path fill="#34a853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/><path fill="#fbbc05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/><path fill="#ea4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/></svg>
                  Continue with Google
                </button>
              </div>

              <div className="flex items-center gap-3 mb-6">
                <div className="flex-1 h-px" style={{ background: 'rgba(124,58,237,0.2)' }} />
                <span className="text-gray-500 text-xs">or</span>
                <div className="flex-1 h-px" style={{ background: 'rgba(124,58,237,0.2)' }} />
              </div>

              {/* Form */}
              <form onSubmit={handleSubmit} className="space-y-4">
                {mode === 'signup' && (
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Display name"
                    required
                    className="w-full px-4 py-3 rounded-xl text-white placeholder-gray-500 text-sm outline-none transition-all"
                    style={{ background: 'rgba(124,58,237,0.08)', border: '1px solid rgba(124,58,237,0.25)', focusBorderColor: '#7c3aed' }}
                  />
                )}
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Email address"
                  required
                  className="w-full px-4 py-3 rounded-xl text-white placeholder-gray-500 text-sm outline-none"
                  style={{ background: 'rgba(124,58,237,0.08)', border: '1px solid rgba(124,58,237,0.25)' }}
                />
                <div className="relative">
                  <input
                    type={showPass ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Password"
                    required
                    className="w-full px-4 py-3 pr-12 rounded-xl text-white placeholder-gray-500 text-sm outline-none"
                    style={{ background: 'rgba(124,58,237,0.08)', border: '1px solid rgba(124,58,237,0.25)' }}
                  />
                  <button type="button" onClick={() => setShowPass(!showPass)} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-300">
                    {showPass ? <EyeOff size={16} /> : <Eye size={16} />}
                  </button>
                </div>

                {error && (
                  <p className="text-red-400 text-xs px-1">{error}</p>
                )}

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full glow-btn py-3 rounded-xl text-white font-semibold text-sm flex items-center justify-center gap-2"
                >
                  {loading ? (
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <>
                      {mode === 'login' ? 'Sign In' : 'Create Account'}
                      <ArrowRight size={16} />
                    </>
                  )}
                </button>
              </form>

              <p className="text-center text-gray-500 text-sm mt-6">
                {mode === 'login' ? (
                  <>Don't have an account?{' '}
                    <button onClick={() => { setMode('signup'); setError('') }} className="text-purple-400 hover:text-purple-300 font-medium">Sign up</button>
                  </>
                ) : (
                  <>Already have one?{' '}
                    <button onClick={() => { setMode('login'); setError('') }} className="text-purple-400 hover:text-purple-300 font-medium">Sign in</button>
                  </>
                )}
              </p>
            </>
          )}
        </div>

        <p className="text-center text-gray-600 text-xs mt-6">
          By continuing, you agree to our Terms of Service.
        </p>
      </div>
    </div>
  )
}
