import { createServerFn } from '@tanstack/react-start'
import { getUser, type User } from '@netlify/identity'

export type { User as IdentityUser }

export const ADMIN_EMAIL = 'eepan7838@gmail.com'

export const getServerUser = createServerFn({ method: 'GET' }).handler(
  async () => {
    const user = await getUser()
    return (user ?? null) as any
  }
)

export function isAdmin(user: User | null): boolean {
  return user?.email === ADMIN_EMAIL
}
