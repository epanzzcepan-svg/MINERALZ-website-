import { createServerFn } from '@tanstack/react-start'
import { db } from '../../db/index.js'
import { texturePacks, downloadLogs, userFavorites } from '../../db/schema.js'
import { eq, desc, and } from 'drizzle-orm'
import { getUser } from '@netlify/identity'

export const getPacks = createServerFn({ method: 'GET' }).handler(async () => {
  const packs = await db
    .select()
    .from(texturePacks)
    .where(eq(texturePacks.visible, true))
    .orderBy(desc(texturePacks.createdAt))
  return packs
})

export const getAllPacks = createServerFn({ method: 'GET' }).handler(async () => {
  const user = await getUser()
  if (!user || user.email !== 'eepan7838@gmail.com') {
    throw new Error('Unauthorized')
  }
  const packs = await db.select().from(texturePacks).orderBy(desc(texturePacks.createdAt))
  return packs
})

export const incrementDownload = createServerFn({ method: 'POST' })
  .validator((data: { packId: number }) => data)
  .handler(async ({ data }) => {
    const user = await getUser()

    // Get current count
    const [pack] = await db.select({ downloads: texturePacks.downloads }).from(texturePacks).where(eq(texturePacks.id, data.packId))
    const newCount = (pack?.downloads ?? 0) + 1

    await db
      .update(texturePacks)
      .set({ downloads: newCount })
      .where(eq(texturePacks.id, data.packId))

    // Log download
    await db.insert(downloadLogs).values({
      userId: user?.id ?? null,
      packId: data.packId,
    })

    return { downloads: newCount }
  })

export const getUserFavorites = createServerFn({ method: 'GET' }).handler(async () => {
  const user = await getUser()
  if (!user) return []
  const favs = await db
    .select({ packId: userFavorites.packId })
    .from(userFavorites)
    .where(eq(userFavorites.userId, user.id))
  return favs.map((f) => f.packId)
})

export const toggleFavorite = createServerFn({ method: 'POST' })
  .validator((data: { packId: number }) => data)
  .handler(async ({ data }) => {
    const user = await getUser()
    if (!user) throw new Error('Not authenticated')
    const existing = await db
      .select()
      .from(userFavorites)
      .where(and(eq(userFavorites.userId, user.id), eq(userFavorites.packId, data.packId)))
    if (existing.length > 0) {
      await db
        .delete(userFavorites)
        .where(and(eq(userFavorites.userId, user.id), eq(userFavorites.packId, data.packId)))
      return { favorited: false }
    } else {
      await db.insert(userFavorites).values({ userId: user.id, packId: data.packId })
      return { favorited: true }
    }
  })

export const getDownloadHistory = createServerFn({ method: 'GET' }).handler(async () => {
  const user = await getUser()
  if (!user) return []
  const logs = await db
    .select({
      id: downloadLogs.id,
      packId: downloadLogs.packId,
      downloadedAt: downloadLogs.downloadedAt,
      packName: texturePacks.name,
      packVersion: texturePacks.version,
    })
    .from(downloadLogs)
    .innerJoin(texturePacks, eq(downloadLogs.packId, texturePacks.id))
    .where(eq(downloadLogs.userId, user.id))
    .orderBy(desc(downloadLogs.downloadedAt))
    .limit(50)
  return logs
})

// Admin functions
export const createPack = createServerFn({ method: 'POST' })
  .validator((data: {
    name: string; version: string; description: string; downloadUrl: string;
    thumbnail: string; compatibility: string; changelog: string
  }) => data)
  .handler(async ({ data }) => {
    const user = await getUser()
    if (!user || user.email !== 'eepan7838@gmail.com') throw new Error('Unauthorized')
    const [pack] = await db.insert(texturePacks).values(data).returning()
    return pack
  })

export const updatePack = createServerFn({ method: 'POST' })
  .validator((data: {
    id: number; name: string; version: string; description: string; downloadUrl: string;
    thumbnail: string; compatibility: string; changelog: string; visible: boolean
  }) => data)
  .handler(async ({ data }) => {
    const user = await getUser()
    if (!user || user.email !== 'eepan7838@gmail.com') throw new Error('Unauthorized')
    const { id, ...rest } = data
    const [pack] = await db.update(texturePacks).set(rest).where(eq(texturePacks.id, id)).returning()
    return pack
  })

export const deletePack = createServerFn({ method: 'POST' })
  .validator((data: { id: number }) => data)
  .handler(async ({ data }) => {
    const user = await getUser()
    if (!user || user.email !== 'eepan7838@gmail.com') throw new Error('Unauthorized')
    await db.delete(texturePacks).where(eq(texturePacks.id, data.id))
    return { success: true }
  })

export const togglePackVisibility = createServerFn({ method: 'POST' })
  .validator((data: { id: number; visible: boolean }) => data)
  .handler(async ({ data }) => {
    const user = await getUser()
    if (!user || user.email !== 'eepan7838@gmail.com') throw new Error('Unauthorized')
    await db.update(texturePacks).set({ visible: data.visible }).where(eq(texturePacks.id, data.id))
    return { success: true }
  })

export const getDashboardStats = createServerFn({ method: 'GET' }).handler(async () => {
  const user = await getUser()
  if (!user || user.email !== 'eepan7838@gmail.com') throw new Error('Unauthorized')
  const packs = await db.select().from(texturePacks)
  const totalDownloads = packs.reduce((sum, p) => sum + p.downloads, 0)
  const totalLogs = await db.select({ id: downloadLogs.id }).from(downloadLogs)
  return {
    totalPacks: packs.length,
    totalDownloads: totalDownloads + totalLogs.length,
  }
})
