# AGENTS.md — Mineralz Purple PvP

This document describes the architecture of the Mineralz Purple PvP website for AI agents and developers.

## Project Overview

A full-stack gaming + SaaS website for the Mineralz Purple PvP Minecraft texture pack. Features include a hero with canvas physics, user auth (Netlify Identity), a downloads system backed by Netlify Database, and an admin panel.

## Tech Stack

| Layer | Technology |
|-------|------------|
| Framework | TanStack Start (React SSR) |
| Routing | TanStack Router v1 (file-based) |
| Build | Vite 7 |
| Styling | TailwindCSS v4 + custom CSS in `src/styles.css` |
| Auth | `@netlify/identity` (Netlify Identity) |
| Database | Netlify Database (Postgres) via Drizzle ORM (beta) |
| Animations | CSS keyframes + Canvas API (custom, no Framer Motion) |
| Deploy | Netlify |

## Directory Structure

```
├── db/
│   ├── schema.ts          # Drizzle ORM schema (source of truth)
│   └── index.ts           # Drizzle client (drizzle-orm/netlify-db)
├── netlify/
│   ├── database/
│   │   └── migrations/    # Auto-generated SQL migrations (never edit manually)
│   └── functions/
│       └── identity-signup.ts  # Netlify Identity webhook
├── public/
│   ├── favicon.ico
│   ├── placeholder.png
│   ├── robots.txt
│   └── sitemap.xml
├── src/
│   ├── components/
│   │   ├── CallbackHandler.tsx   # OAuth token handler (mounted in root)
│   │   ├── FAQAccordion.tsx      # Shared FAQ component
│   │   ├── FeaturesGrid.tsx      # Feature cards with hover effects
│   │   ├── FloatingActions.tsx   # Download CTA, back-to-top, Konami egg
│   │   ├── Footer.tsx
│   │   ├── Hero.tsx              # Canvas falling blocks + typewriter
│   │   ├── Navbar.tsx            # Glassmorphic sticky nav
│   │   ├── ScreenshotGallery.tsx # Masonry gallery + lightbox
│   │   └── StatsCounter.tsx      # Animated count-up stats
│   ├── lib/
│   │   ├── auth.ts               # getServerUser server fn, ADMIN_EMAIL, isAdmin()
│   │   ├── identity-context.tsx  # React context for client-side auth state
│   │   └── packs.ts              # Server functions for pack CRUD + downloads
│   ├── middleware/
│   │   └── identity.ts           # Auth middleware (identityMiddleware, requireAuthMiddleware)
│   ├── routes/
│   │   ├── __root.tsx            # Root layout (IdentityProvider, CallbackHandler, Navbar, Footer)
│   │   ├── index.tsx             # Homepage (Hero + StatsCounter + FeaturesGrid + Gallery + FAQ)
│   │   ├── downloads.tsx         # Downloads page with chest animation
│   │   ├── installation.tsx      # Interactive install guide (Bedrock + Java tabs)
│   │   ├── changelog.tsx         # Timeline changelog
│   │   ├── faq.tsx               # FAQ standalone page
│   │   ├── login.tsx             # Login/signup (email + OAuth)
│   │   ├── profile.tsx           # User profile, favorites, download history
│   │   └── admin/
│   │       └── index.tsx         # Admin dashboard (restricted to eepan7838@gmail.com)
│   ├── router.tsx                # Router setup
│   └── styles.css                # Global CSS (Tailwind + custom animations + design tokens)
├── drizzle.config.ts             # Drizzle Kit config (output → netlify/database/migrations)
└── netlify.toml                  # Build config
```

## Design System

- **Background**: `#0a0a0a` → `#1a0a2e` gradient
- **Accent**: `#7c3aed` (neon purple)
- **Glass cards**: `.glass-card` CSS class (backdrop-filter blur)
- **Title font**: Press Start 2P (pixel font via Google Fonts)
- **Body font**: Inter
- **CSS variables**: defined in `:root` in `src/styles.css`

## Auth Architecture

- Client state: `useIdentity()` hook from `src/lib/identity-context.tsx`
- Server state: `getServerUser()` from `src/lib/auth.ts` (used in `beforeLoad`)
- Admin gate: check `user.email === 'eepan7838@gmail.com'` (in client and server)
- OAuth callback: `CallbackHandler` mounted in `__root.tsx` handles hash tokens

## Database

Schema defined in `db/schema.ts`:
- `texture_packs` — pack metadata + download count
- `user_favorites` — user ↔ pack many-to-many
- `download_logs` — per-download audit log

After schema changes: run `npx drizzle-kit generate` to create migration files. Never apply manually.

## Key Conventions

- Server functions live in `src/lib/*.ts` using `createServerFn`
- Routes use `createFileRoute` — file path = URL
- Admin email `ADMIN_EMAIL` is defined in `src/lib/auth.ts`
- All animations use CSS keyframes or `requestAnimationFrame` — no heavy animation library
- No TypeScript `any` except where forced by `@netlify/identity` return types
